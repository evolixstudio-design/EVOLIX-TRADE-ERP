import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatCard } from "@/components/common/StatCard";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { attendanceStore } from "@/lib/stores/attendance";
import { families } from "@/lib/mock-data";
import { Check, X, UtensilsCrossed, CalendarDays } from "lucide-react";

export const Route = createFileRoute("/_app/thali/history")({
  component: HistoryPage,
});

type Row = {
  id: string;
  date: string;
  total: number;
  taken: number;
  notTaken: number;
  unmarked: number;
  rate: string;
};

function HistoryPage() {
  const records = attendanceStore.useStore();
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + "01";
  const [from, setFrom] = useState(monthStart);
  const [to, setTo] = useState(today);
  const [family, setFamily] = useState<string>("");

  const filteredByFamily = useMemo(
    () => (family ? records.filter((r) => r.familyId === family) : records),
    [records, family],
  );

  const rows = useMemo<Row[]>(() => {
    const byDate = new Map<string, { taken: number; notTaken: number }>();
    filteredByFamily.forEach((r) => {
      if (r.date < from || r.date > to) return;
      const b = byDate.get(r.date) ?? { taken: 0, notTaken: 0 };
      if (r.status === "Taken") b.taken++;
      else b.notTaken++;
      byDate.set(r.date, b);
    });
    const total = family ? 1 : families.length;
    return Array.from(byDate.entries())
      .sort((a, b) => (a[0] < b[0] ? 1 : -1))
      .map(([date, v]) => ({
        id: date,
        date,
        total,
        taken: v.taken,
        notTaken: v.notTaken,
        unmarked: Math.max(0, total - v.taken - v.notTaken),
        rate: total ? `${Math.round((v.taken / total) * 100)}%` : "—",
      }));
  }, [filteredByFamily, from, to, family]);

  const summary = useMemo(() => {
    const taken = rows.reduce((s, r) => s + r.taken, 0);
    const notTaken = rows.reduce((s, r) => s + r.notTaken, 0);
    return { taken, notTaken, days: rows.length };
  }, [rows]);

  const columns: Column<Row>[] = [
    { key: "date", header: "Date", accessor: (r) => r.date },
    { key: "total", header: "Total", align: "center", accessor: (r) => r.total },
    {
      key: "taken", header: "Taken", align: "center",
      render: (r) => <span className="font-semibold text-success">{r.taken}</span>,
      accessor: (r) => r.taken,
    },
    {
      key: "notTaken", header: "Not Taken", align: "center",
      render: (r) => <span className="font-semibold text-destructive">{r.notTaken}</span>,
      accessor: (r) => r.notTaken,
    },
    { key: "unmarked", header: "Unmarked", align: "center", accessor: (r) => r.unmarked },
    { key: "rate", header: "Rate", align: "center", accessor: (r) => r.rate },
  ];

  return (
    <div>
      <PageHeader
        title="Thali History"
        subtitle="Historical daily attendance with date range and family filters."
      />

      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <StatCard label="Days in range" value={String(summary.days)} icon={CalendarDays} tone="default" />
        <StatCard label="Total Taken" value={String(summary.taken)} icon={Check} tone="success" />
        <StatCard label="Total Not Taken" value={String(summary.notTaken)} icon={X} tone="destructive" />
        <StatCard label="Distributed / Day" value={summary.days ? String(Math.round(summary.taken / summary.days)) : "0"} icon={UtensilsCrossed} tone="gold" />
      </div>

      <div className="mb-4 flex flex-wrap items-end gap-3 rounded-xl border bg-card p-4 shadow-soft">
        <div>
          <Label className="text-xs text-muted-foreground">From</Label>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-[170px]" />
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">To</Label>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-[170px]" />
        </div>
        <div className="min-w-[220px] flex-1">
          <Label className="text-xs text-muted-foreground">Family</Label>
          <select
            value={family}
            onChange={(e) => setFamily(e.target.value)}
            className="mt-1 flex h-9 w-full items-center rounded-md border bg-background px-3 text-sm"
          >
            <option value="">All families</option>
            {families.map((f) => (
              <option key={f.id} value={f.id}>{f.thaliNo} · {f.head}</option>
            ))}
          </select>
        </div>
      </div>

      <DataTable
        data={rows}
        columns={columns}
        exportFilename={`thali-history-${from}-to-${to}`}
        pageSize={15}
        empty="No attendance in this range"
      />
    </div>
  );
}
