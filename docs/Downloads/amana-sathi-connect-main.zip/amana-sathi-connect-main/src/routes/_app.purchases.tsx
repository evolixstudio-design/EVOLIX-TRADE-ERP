import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { StatusBadge } from "@/components/common/StatusBadge";
import { purchases, suppliers, type Purchase } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/purchases")({
  component: PurchasesPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  billNo: z.string().trim().min(3, "Bill number is required").max(40),
  date: z.string().min(1, "Date is required"),
  supplier: z.string().trim().min(2, "Supplier is required"),
  items: z.coerce.number().int().min(1, "At least 1 item"),
  amount: z.coerce.number().min(0, "Amount cannot be negative"),
  gst: z.coerce.number().min(0, "GST cannot be negative").default(0),
  total: z.coerce.number().min(0).default(0),
  status: z.enum(["Paid", "Pending", "Partial"]),
}) as unknown as z.ZodType<Purchase>;

const supplierOptions = suppliers.map((s) => ({ label: s.name, value: s.name }));

const fields: FieldConfig<Purchase>[] = [
  { name: "billNo", label: "Bill Number", placeholder: "BILL/2025/0100" },
  { name: "date", label: "Bill Date", type: "date" },
  { name: "supplier", label: "Supplier", type: "select", options: supplierOptions, colSpan: 2 },
  { name: "items", label: "No. of Items", type: "number" },
  { name: "status", label: "Status", type: "select", options: [
    { label: "Paid", value: "Paid" },
    { label: "Pending", value: "Pending" },
    { label: "Partial", value: "Partial" },
  ]},
  { name: "amount", label: "Amount (₹)", type: "number" },
  { name: "gst", label: "GST (₹)", type: "number" },
];

const empty: Purchase = {
  id: "",
  billNo: "",
  date: new Date().toISOString().slice(0, 10),
  supplier: supplierOptions[0]?.value ?? "",
  items: 1,
  amount: 0,
  gst: 0,
  total: 0,
  status: "Pending",
};

function PurchasesPage() {
  const columns: Column<Purchase>[] = [
    { key: "billNo", header: "Bill No", render: (r) => <span className="font-mono">{r.billNo}</span>, accessor: (r) => r.billNo },
    { key: "date", header: "Date", accessor: (r) => r.date },
    { key: "supplier", header: "Supplier", accessor: (r) => r.supplier },
    { key: "items", header: "Items", align: "center", accessor: (r) => r.items },
    { key: "amount", header: "Amount", align: "right", render: (r) => inr(r.amount), accessor: (r) => r.amount },
    { key: "gst", header: "GST", align: "right", render: (r) => r.gst ? inr(r.gst) : "—", accessor: (r) => r.gst },
    { key: "total", header: "Total", align: "right", render: (r) => <span className="font-semibold">{inr(r.total)}</span>, accessor: (r) => r.total },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, accessor: (r) => r.status },
  ];
  return (
    <CrudResourcePage<Purchase>
      title="Purchases"
      subtitle="Purchase bills and orders from all suppliers."
      seed={purchases}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="New Purchase"
      entityLabel="Purchase"
      idPrefix="PO"
      derive={(r) => ({ ...r, total: Number(r.amount) + Number(r.gst) })}
    />
  );
}
