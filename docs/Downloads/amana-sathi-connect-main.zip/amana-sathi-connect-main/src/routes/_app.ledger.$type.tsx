import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { DataTable, type Column } from "@/components/common/DataTable";
import { Card, CardContent } from "@/components/ui/card";
import { ledger, type LedgerEntry } from "@/lib/mock-data";
import { inr } from "@/lib/format";

export const Route = createFileRoute("/_app/ledger/$type")({
  component: LedgerPage,
});

const titles: Record<string, string> = {
  general: "General Ledger",
  member: "Member Ledger",
  supplier: "Supplier Ledger",
  bank: "Bank Ledger",
  cash: "Cash Ledger",
  expense: "Expense Ledger",
  income: "Income Ledger",
  donation: "Donation Ledger",
};

const columns: Column<LedgerEntry>[] = [
  { key: "date", header: "Date", accessor: (r) => r.date },
  { key: "vch", header: "Voucher", render: (r) => <span className="font-mono">{r.vch}</span>, accessor: (r) => r.vch },
  { key: "particulars", header: "Particulars", accessor: (r) => r.particulars },
  { key: "debit", header: "Debit", align: "right", render: (r) => r.debit ? inr(r.debit) : "—", accessor: (r) => r.debit },
  { key: "credit", header: "Credit", align: "right", render: (r) => r.credit ? inr(r.credit) : "—", accessor: (r) => r.credit },
  { key: "balance", header: "Balance", align: "right", render: (r) => <span className="font-semibold">{inr(r.balance)}</span>, accessor: (r) => r.balance },
];

function LedgerPage() {
  const { type } = Route.useParams();
  const title = titles[type] ?? "Ledger";
  const totalDr = ledger.reduce((s, l) => s + l.debit, 0);
  const totalCr = ledger.reduce((s, l) => s + l.credit, 0);
  const opening = 125000;
  const closing = ledger[ledger.length - 1]?.balance ?? opening;

  return (
    <div>
      <PageHeader title={title} subtitle="Running balance with debit/credit entries." />
      <div className="mb-6 grid gap-4 md:grid-cols-4">
        {[
          { l: "Opening Balance", v: inr(opening) },
          { l: "Total Debit", v: inr(totalDr) },
          { l: "Total Credit", v: inr(totalCr) },
          { l: "Closing Balance", v: inr(closing) },
        ].map((s) => (
          <Card key={s.l} className="shadow-soft">
            <CardContent className="p-4">
              <p className="text-xs uppercase text-muted-foreground">{s.l}</p>
              <p className="mt-1 text-xl font-semibold tabular-nums">{s.v}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <DataTable data={ledger} columns={columns} pageSize={12} />
    </div>
  );
}
