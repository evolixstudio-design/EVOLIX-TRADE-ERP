import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { StatusBadge } from "@/components/common/StatusBadge";
import { invoices, families, type Invoice } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/invoices")({
  component: InvoicesPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  no: z.string().trim().min(3, "Invoice number is required").max(40),
  date: z.string().min(1, "Date is required"),
  family: z.string().trim().min(2, "Family is required"),
  thaliNo: z.string().trim().min(1, "Thali number is required").max(20),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  paid: z.coerce.number().min(0, "Paid cannot be negative"),
  balance: z.coerce.number().default(0),
  status: z.enum(["Paid", "Partial", "Unpaid", "Overdue"]),
}) as unknown as z.ZodType<Invoice>;

const familyOptions = Array.from(new Set(families.map((f) => f.head))).map((n) => ({
  label: n,
  value: n,
}));

const fields: FieldConfig<Invoice>[] = [
  { name: "no", label: "Invoice No", placeholder: "FMB/2025/01001" },
  { name: "date", label: "Date", type: "date" },
  { name: "family", label: "Family", type: "select", options: familyOptions, colSpan: 2 },
  { name: "thaliNo", label: "Thali No" },
  { name: "status", label: "Status", type: "select", options: [
    { label: "Paid", value: "Paid" },
    { label: "Partial", value: "Partial" },
    { label: "Unpaid", value: "Unpaid" },
    { label: "Overdue", value: "Overdue" },
  ]},
  { name: "amount", label: "Amount (₹)", type: "number" },
  { name: "paid", label: "Paid (₹)", type: "number" },
];

const empty: Invoice = {
  id: "",
  no: "",
  date: new Date().toISOString().slice(0, 10),
  family: familyOptions[0]?.value ?? "",
  thaliNo: "",
  amount: 1200,
  paid: 0,
  balance: 1200,
  status: "Unpaid",
};

const columns: Column<Invoice>[] = [
  { key: "no", header: "Invoice No", render: (r) => <span className="font-mono font-medium">{r.no}</span>, accessor: (r) => r.no },
  { key: "date", header: "Date", accessor: (r) => r.date },
  { key: "family", header: "Family", accessor: (r) => r.family },
  { key: "thaliNo", header: "Thali", accessor: (r) => r.thaliNo },
  { key: "amount", header: "Amount", align: "right", render: (r) => inr(r.amount), accessor: (r) => r.amount },
  { key: "paid", header: "Paid", align: "right", render: (r) => inr(r.paid), accessor: (r) => r.paid },
  {
    key: "balance", header: "Balance", align: "right",
    render: (r) => <span className={r.balance > 0 ? "font-semibold text-destructive" : ""}>{inr(r.balance)}</span>,
    accessor: (r) => r.balance,
  },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, accessor: (r) => r.status },
];

function InvoicesPage() {
  return (
    <CrudResourcePage<Invoice>
      title="Invoices"
      subtitle="Monthly contribution invoices, extra thali charges and outstanding balances."
      seed={invoices}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="Generate Invoice"
      entityLabel="Invoice"
      idPrefix="INV"
      derive={(r) => {
        const balance = Math.max(0, Number(r.amount) - Number(r.paid));
        const status: Invoice["status"] =
          r.paid <= 0 ? "Unpaid" : balance === 0 ? "Paid" : "Partial";
        return { ...r, balance, status };
      }}
    />
  );
}
