import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatCard } from "@/components/common/StatCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Plus, Package, AlertTriangle, Layers, IndianRupee, Trash2 } from "lucide-react";
import { stock, type StockItem } from "@/lib/mock-data";
import { inr, num } from "@/lib/format";
import { FormModal, type FieldConfig } from "@/components/common/FormModal";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { useCrud } from "@/hooks/use-crud";

export const Route = createFileRoute("/_app/stock")({
  component: StockPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  name: z.string().trim().min(2, "Item name is required").max(80),
  category: z.string().trim().min(2, "Category is required"),
  unit: z.string().trim().min(1, "Unit is required").max(10),
  qty: z.coerce.number().min(0, "Quantity cannot be negative"),
  min: z.coerce.number().min(0, "Min cannot be negative"),
  rate: z.coerce.number().min(0, "Rate cannot be negative"),
  value: z.coerce.number().min(0).default(0),
  lastPurchase: z.string().min(1, "Last purchase date is required"),
}) as unknown as z.ZodType<StockItem>;

const fields: FieldConfig<StockItem>[] = [
  { name: "name", label: "Item Name", placeholder: "e.g. Basmati Rice", colSpan: 2 },
  { name: "category", label: "Category", type: "select", options: [
    { label: "Grocery", value: "Grocery" },
    { label: "Vegetables", value: "Vegetables" },
    { label: "Milk", value: "Milk" },
    { label: "Gas", value: "Gas" },
    { label: "Disposable", value: "Disposable" },
    { label: "Cleaning", value: "Cleaning" },
  ]},
  { name: "unit", label: "Unit", type: "select", options: [
    { label: "kg", value: "kg" },
    { label: "ltr", value: "ltr" },
    { label: "pcs", value: "pcs" },
    { label: "gm", value: "gm" },
  ]},
  { name: "qty", label: "Quantity", type: "number", step: "0.01" },
  { name: "min", label: "Min Stock", type: "number", step: "0.01" },
  { name: "rate", label: "Rate (₹)", type: "number", step: "0.01" },
  { name: "lastPurchase", label: "Last Purchase Date", type: "date", colSpan: 2 },
];

const empty: StockItem = {
  id: "",
  name: "",
  category: "Grocery",
  unit: "kg",
  qty: 0,
  min: 0,
  rate: 0,
  value: 0,
  lastPurchase: new Date().toISOString().slice(0, 10),
};

function StockPage() {
  const { items, create, update, remove } = useCrud<StockItem>(stock, {
    idPrefix: "SKU",
    label: "Stock Item",
    derive: (r) => ({ ...r, value: Number(r.qty) * Number(r.rate) }),
  });

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<StockItem | null>(null);
  const [deleting, setDeleting] = useState<StockItem | null>(null);

  const totals = useMemo(() => {
    const totalValue = items.reduce((s, i) => s + i.value, 0);
    const low = items.filter((s) => s.qty <= s.min).length;
    const categories = new Set(items.map((s) => s.category)).size;
    return { totalValue, low, categories };
  }, [items]);

  const columns: Column<StockItem>[] = [
    { key: "name", header: "Item", render: (r) => <span className="font-medium">{r.name}</span>, accessor: (r) => r.name },
    { key: "category", header: "Category", render: (r) => <Badge variant="outline">{r.category}</Badge>, accessor: (r) => r.category },
    { key: "qty", header: "Qty", align: "right", render: (r) => <span className={r.qty <= r.min ? "font-semibold text-destructive" : ""}>{num(r.qty)} {r.unit}</span>, accessor: (r) => r.qty },
    { key: "min", header: "Min", align: "right", render: (r) => `${r.min} ${r.unit}`, accessor: (r) => r.min },
    { key: "rate", header: "Rate", align: "right", render: (r) => inr(r.rate), accessor: (r) => r.rate },
    { key: "value", header: "Stock Value", align: "right", render: (r) => <span className="font-semibold">{inr(r.value)}</span>, accessor: (r) => r.value },
    { key: "lastPurchase", header: "Last Purchase", accessor: (r) => r.lastPurchase },
    {
      key: "__actions", header: "", align: "right",
      render: (r) => (
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(r); setFormOpen(true); }}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleting(r)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Stock Inventory"
        subtitle="Kitchen inventory across grocery, vegetables, milk and consumables."
        actions={
          <Button className="gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="h-4 w-4" /> Add Item
          </Button>
        }
      />
      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <StatCard label="Total SKUs" value={String(items.length)} icon={Package} tone="default" />
        <StatCard label="Categories" value={String(totals.categories)} icon={Layers} tone="info" />
        <StatCard label="Low Stock" value={String(totals.low)} icon={AlertTriangle} tone="destructive" />
        <StatCard label="Stock Value" value={inr(totals.totalValue)} icon={IndianRupee} tone="gold" />
      </div>
      <DataTable data={items} columns={columns} pageSize={12} />

      <FormModal<StockItem>
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit Stock Item" : "New Stock Item"}
        fields={fields}
        schema={schema}
        defaultValues={editing ?? empty}
        submitLabel={editing ? "Update" : "Create"}
        onSubmit={(v) => (editing ? update(editing.id, v) : create(v))}
      />
      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="Delete Stock Item?"
        description="This item will be removed from inventory."
        onConfirm={() => {
          if (deleting) remove(deleting.id);
          setDeleting(null);
        }}
      />
    </div>
  );
}
