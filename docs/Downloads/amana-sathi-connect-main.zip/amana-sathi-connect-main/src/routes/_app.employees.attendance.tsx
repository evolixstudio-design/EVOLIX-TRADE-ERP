import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { employees } from "@/lib/mock-data";
import { Check, X, Clock } from "lucide-react";

export const Route = createFileRoute("/_app/employees/attendance")({
  component: () => {
    const days = Array.from({ length: 30 }, (_, i) => i + 1);
    return (
      <div>
        <PageHeader title="Attendance" subtitle="Monthly attendance for all employees." />
        <Card className="shadow-soft">
          <CardContent className="overflow-x-auto p-0">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="sticky left-0 z-10 bg-muted/40 px-4 py-3 text-left font-semibold uppercase tracking-wide text-muted-foreground">Employee</th>
                  {days.map((d) => <th key={d} className="px-2 py-3 text-center font-semibold text-muted-foreground">{d}</th>)}
                </tr>
              </thead>
              <tbody>
                {employees.map((e, ei) => (
                  <tr key={e.id} className="border-b hover:bg-muted/20">
                    <td className="sticky left-0 z-10 bg-card px-4 py-2.5 font-medium">{e.name}</td>
                    {days.map((d) => {
                      const state = (ei + d) % 11 === 0 ? "absent" : (ei + d) % 7 === 0 ? "half" : "present";
                      return (
                        <td key={d} className="px-2 py-2.5 text-center">
                          {state === "present" && <Check className="mx-auto h-3.5 w-3.5 text-success" />}
                          {state === "absent" && <X className="mx-auto h-3.5 w-3.5 text-destructive" />}
                          {state === "half" && <Clock className="mx-auto h-3.5 w-3.5 text-warning" />}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    );
  },
});
