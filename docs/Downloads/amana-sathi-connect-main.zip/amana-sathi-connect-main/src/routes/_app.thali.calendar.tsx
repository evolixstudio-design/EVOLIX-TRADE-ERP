import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { attendanceStore, monthSummary } from "@/lib/stores/attendance";
import { families } from "@/lib/mock-data";

export const Route = createFileRoute("/_app/thali/calendar")({
  component: CalendarPage,
});

function CalendarPage() {
  const today = new Date();
  const [cursor, setCursor] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const records = attendanceStore.useStore();

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const startDay = new Date(year, month, 1).getDay();
  const cells: (number | null)[] = [
    ...Array(startDay).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  const summary = useMemo(() => monthSummary(records, year, month), [records, year, month]);
  const byDate = useMemo(() => {
    const map = new Map<string, { taken: number; notTaken: number }>();
    records.forEach((r) => {
      const d = new Date(r.date);
      if (d.getFullYear() !== year || d.getMonth() !== month) return;
      const b = map.get(r.date) ?? { taken: 0, notTaken: 0 };
      if (r.status === "Taken") b.taken++;
      else b.notTaken++;
      map.set(r.date, b);
    });
    return map;
  }, [records, year, month]);

  const total = families.length;

  return (
    <div>
      <PageHeader
        title="Thali Calendar"
        subtitle={cursor.toLocaleDateString("en-IN", { month: "long", year: "numeric" })}
        actions={
          <>
            <Button variant="outline" size="icon" onClick={() => setCursor(new Date(year, month - 1, 1))}><ChevronLeft className="h-4 w-4" /></Button>
            <Button variant="outline" onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}>Today</Button>
            <Button variant="outline" size="icon" onClick={() => setCursor(new Date(year, month + 1, 1))}><ChevronRight className="h-4 w-4" /></Button>
          </>
        }
      />

      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <SummaryStat label="Active Days" value={summary.days} />
        <SummaryStat label="Total Taken" value={summary.taken} tone="text-success" />
        <SummaryStat label="Total Not Taken" value={summary.notTaken} tone="text-destructive" />
        <SummaryStat label="Avg / Day" value={summary.days ? Math.round(summary.taken / summary.days) : 0} tone="text-primary" />
      </div>

      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="mb-4 flex flex-wrap gap-3 text-xs">
            <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-success" /> Attendance recorded</span>
            <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-muted" /> No entries</span>
            <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded bg-primary/20 ring-2 ring-primary" /> Today</span>
          </div>
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-semibold text-muted-foreground">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => <div key={d} className="py-2">{d}</div>)}
          </div>
          <div className="mt-2 grid grid-cols-7 gap-2">
            {cells.map((d, i) => {
              if (d === null) return <div key={i} />;
              const iso = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
              const b = byDate.get(iso);
              const isToday = iso === today.toISOString().slice(0, 10);
              const hasData = !!b;
              const rate = b ? Math.round((b.taken / total) * 100) : 0;
              return (
                <div
                  key={i}
                  className={`min-h-[86px] rounded-lg border p-2 text-left text-sm transition-colors hover:border-primary ${
                    hasData ? "bg-success/5 border-success/20" : "bg-card"
                  } ${isToday ? "ring-2 ring-primary" : ""}`}
                >
                  <div className="flex items-start justify-between">
                    <span className={`font-semibold ${isToday ? "text-primary" : ""}`}>{d}</span>
                    {hasData && <span className="text-[10px] font-semibold text-success">{rate}%</span>}
                  </div>
                  {hasData ? (
                    <div className="mt-1.5 space-y-0.5 text-[11px]">
                      <p className="text-success">✓ {b.taken}</p>
                      <p className="text-destructive">✕ {b.notTaken}</p>
                    </div>
                  ) : (
                    <p className="mt-2 text-[11px] text-muted-foreground">No entries</p>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function SummaryStat({ label, value, tone = "text-foreground" }: { label: string; value: number; tone?: string }) {
  return (
    <Card className="shadow-soft">
      <CardContent className="p-4">
        <p className="text-xs uppercase text-muted-foreground">{label}</p>
        <p className={`mt-1 text-xl font-semibold tabular-nums ${tone}`}>{value}</p>
      </CardContent>
    </Card>
  );
}
