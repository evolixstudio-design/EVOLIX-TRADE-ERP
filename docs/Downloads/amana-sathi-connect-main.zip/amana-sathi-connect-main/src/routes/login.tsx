import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { UtensilsCrossed } from "lucide-react";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@fmbratangarh.org");
  const [password, setPassword] = useState("demo1234");
  const [remember, setRemember] = useState(true);
  const [forgot, setForgot] = useState(false);

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-primary text-primary-foreground lg:block">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary to-secondary" />
        <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-gold/20 blur-3xl" />
        <div className="absolute -top-24 -left-24 h-72 w-72 rounded-full bg-secondary/40 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gold text-gold-foreground shadow-elevated">
              <UtensilsCrossed className="h-6 w-6" />
            </div>
            <div>
              <p className="font-semibold">FMB Ratangarh</p>
              <p className="text-xs text-primary-foreground/70">Faizul Mawaid Burhaniya</p>
            </div>
          </div>
          <div className="max-w-md">
            <h1 className="text-4xl font-semibold leading-tight">
              Serving the community, <span className="text-gold">one thali at a time.</span>
            </h1>
            <p className="mt-4 text-sm text-primary-foreground/80">
              A complete enterprise system for daily thali distribution, member accounts,
              banking, purchases, stock and reports — designed for Bohra jamaats.
            </p>
            <div className="mt-8 grid grid-cols-3 gap-4 text-center">
              {[
                { k: "480+", v: "Families" },
                { k: "108", v: "Thali / day" },
                { k: "₹2.1L", v: "Monthly" },
              ].map((s) => (
                <div key={s.v} className="rounded-xl bg-primary-foreground/5 p-3 backdrop-blur">
                  <p className="text-lg font-semibold text-gold">{s.k}</p>
                  <p className="text-[11px] text-primary-foreground/70">{s.v}</p>
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-primary-foreground/60">© 1447 H · All Rights Reserved</p>
        </div>
      </div>
      <div className="flex items-center justify-center bg-background p-6">
        <Card className="w-full max-w-md shadow-elevated">
          <CardContent className="p-8">
            <div className="mb-6 flex items-center gap-2 lg:hidden">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <UtensilsCrossed className="h-4 w-4" />
              </div>
              <p className="font-semibold">FMB Ratangarh</p>
            </div>
            <h2 className="text-2xl font-semibold tracking-tight">
              {forgot ? "Reset your password" : "Welcome back"}
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {forgot ? "We'll email you a reset link." : "Sign in to your FMB dashboard."}
            </p>
            <form
              className="mt-6 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                if (!forgot) navigate({ to: "/dashboard" });
              }}
            >
              <div className="space-y-1.5">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              {!forgot && (
                <div className="space-y-1.5">
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
              )}
              {!forgot && (
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2">
                    <Checkbox checked={remember} onCheckedChange={(v) => setRemember(!!v)} />
                    <span>Remember me</span>
                  </label>
                  <button type="button" onClick={() => setForgot(true)} className="text-primary hover:underline">
                    Forgot password?
                  </button>
                </div>
              )}
              <Button type="submit" className="w-full">
                {forgot ? "Send reset link" : "Sign in"}
              </Button>
              {forgot && (
                <Button type="button" variant="ghost" className="w-full" onClick={() => setForgot(false)}>
                  Back to sign in
                </Button>
              )}
            </form>
            <p className="mt-6 text-center text-xs text-muted-foreground">
              Demo: any credentials will sign you in.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
