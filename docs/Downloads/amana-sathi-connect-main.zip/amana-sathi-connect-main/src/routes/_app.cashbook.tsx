import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatCard } from "@/components/common/StatCard";
import { cashBook } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import { Coins, ArrowDownRight, ArrowUpRight, Wallet } from "lucide-react";

export const Route = createFileRoute("/_app/cashbook")({
  component: () => {
    const columns: Column<(typeof cashBook)[number]>[] = [
      { key: "date", header: "Date", accessor: (r) => r.date },
      { key: "opening", header: "Opening", align: "right", render: (r) => inr(r.opening), accessor: (r) => r.opening },
      { key: "received", header: "Received", align: "right", render: (r) => <span className="text-success">{inr(r.received)}</span>, accessor: (r) => r.received },
      { key: "paid", header: "Paid", align: "right", render: (r) => <span className="text-destructive">{inr(r.paid)}</span>, accessor: (r) => r.paid },
      { key: "closing", header: "Closing", align: "right", render: (r) => <span className="font-semibold">{inr(r.closing)}</span>, accessor: (r) => r.closing },
    ];
    const totals = cashBook.reduce((a, r) => ({ received: a.received + r.received, paid: a.paid + r.paid }), { received: 0, paid: 0 });
    return (
      <div>
        <PageHeader title="Cash Book" subtitle="Daily cash inflow and outflow with running closing." />
        <div className="mb-6 grid gap-4 md:grid-cols-4">
          <StatCard label="Opening Cash" value={inr(cashBook[0].opening)} icon={Coins} tone="default" />
          <StatCard label="Total Received" value={inr(totals.received)} icon={ArrowUpRight} tone="success" />
          <StatCard label="Total Paid" value={inr(totals.paid)} icon={ArrowDownRight} tone="destructive" />
          <StatCard label="Closing Cash" value={inr(cashBook[cashBook.length - 1].closing)} icon={Wallet} tone="gold" />
        </div>
        <DataTable data={cashBook} columns={columns} pageSize={12} />
      </div>
    );
  },
});
