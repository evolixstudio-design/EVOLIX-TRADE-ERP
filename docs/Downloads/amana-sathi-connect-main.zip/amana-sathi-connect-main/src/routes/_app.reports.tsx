import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { FileDown, Printer } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";
import { monthlyCollection, suppliers, expenses } from "@/lib/mock-data";
import { inr } from "@/lib/format";

export const Route = createFileRoute("/_app/reports")({
  component: ReportsPage,
});

const reportGroups = [
  { title: "Financial", items: ["Collection Report", "Outstanding Report", "Cash Book", "Bank Report", "Cheque Report", "Ledger Report"] },
  { title: "Operations", items: ["Distribution Report", "Stock Report", "Purchase Report", "Expense Report"] },
  { title: "Community", items: ["Family Report", "Donation Report", "Supplier Report", "Monthly Report", "Yearly Report"] },
];

const CATEGORY_COLORS = ["var(--primary)", "var(--gold)", "var(--info)", "var(--success)", "var(--destructive)", "var(--secondary)"];

function ReportsPage() {
  const byCategory = Object.entries(
    expenses.reduce<Record<string, number>>((a, e) => { a[e.category] = (a[e.category] ?? 0) + e.amount; return a; }, {})
  ).map(([name, value]) => ({ name, value }));
  const bySupplier = suppliers.map((s) => ({ name: s.name.split(" ")[0], outstanding: s.outstanding }));

  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle="Financial, operational and community reports."
        actions={
          <>
            <Button variant="outline" className="gap-1.5"><Printer className="h-4 w-4" /> Print</Button>
            <Button className="gap-1.5"><FileDown className="h-4 w-4" /> Export</Button>
          </>
        }
      />
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="catalog">Report Catalog</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="mt-6 grid gap-4 lg:grid-cols-2">
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Collection vs Expense (7 months)</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={monthlyCollection}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(v) => `${v / 1000}k`} />
                  <Tooltip formatter={(v: number) => inr(v)} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
                  <Legend />
                  <Bar dataKey="collection" fill="var(--primary)" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="expense" fill="var(--gold)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Expense by Category</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={byCategory} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={2}>
                    {byCategory.map((_, i) => <Cell key={i} fill={CATEGORY_COLORS[i % CATEGORY_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v: number) => inr(v)} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          <Card className="shadow-soft lg:col-span-2">
            <CardHeader><CardTitle className="text-base">Supplier Outstanding</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={bySupplier} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
                  <XAxis type="number" className="text-xs" tickFormatter={(v) => `${v / 1000}k`} />
                  <YAxis type="category" dataKey="name" className="text-xs" width={90} />
                  <Tooltip formatter={(v: number) => inr(v)} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
                  <Bar dataKey="outstanding" fill="var(--secondary)" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="catalog" className="mt-6 grid gap-4 md:grid-cols-3">
          {reportGroups.map((g) => (
            <Card key={g.title} className="shadow-soft">
              <CardHeader><CardTitle className="text-base">{g.title}</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {g.items.map((i) => (
                  <button key={i} className="flex w-full items-center justify-between rounded-lg border px-3 py-2 text-sm transition-colors hover:border-primary hover:bg-muted/50">
                    <span>{i}</span>
                    <FileDown className="h-4 w-4 text-muted-foreground" />
                  </button>
                ))}
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
