import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Save, Database, Bell, Shield, Palette, Users } from "lucide-react";

export const Route = createFileRoute("/_app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <div>
      <PageHeader title="Settings" subtitle="Organization, users, permissions, theme and backup." />
      <Tabs defaultValue="org">
        <TabsList className="flex-wrap">
          <TabsTrigger value="org"><Database className="mr-1.5 h-4 w-4" /> Organization</TabsTrigger>
          <TabsTrigger value="users"><Users className="mr-1.5 h-4 w-4" /> Users & Roles</TabsTrigger>
          <TabsTrigger value="theme"><Palette className="mr-1.5 h-4 w-4" /> Theme</TabsTrigger>
          <TabsTrigger value="notify"><Bell className="mr-1.5 h-4 w-4" /> Notifications</TabsTrigger>
          <TabsTrigger value="backup"><Shield className="mr-1.5 h-4 w-4" /> Backup</TabsTrigger>
        </TabsList>

        <TabsContent value="org" className="mt-6">
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Organization Profile</CardTitle></CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <Field label="Organization Name" value="Faizul Mawaid Burhaniya Ratangarh" />
              <Field label="Registration No." value="TRUST/RJ/2018/00453" />
              <Field label="Address" value="Bohra Mohalla, Ratangarh" />
              <Field label="City / PIN" value="Ratangarh, 331022" />
              <Field label="Contact" value="+91 98765 43210" />
              <Field label="Email" value="office@fmbratangarh.org" />
              <div className="md:col-span-2 space-y-1.5">
                <Label>About</Label>
                <Textarea rows={3} defaultValue="Community trust operating daily thali distribution and welfare programs for Bohra families of Ratangarh." />
              </div>
              <div className="md:col-span-2 flex justify-end"><Button className="gap-1.5"><Save className="h-4 w-4" /> Save Changes</Button></div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="mt-6">
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Users</CardTitle></CardHeader>
            <CardContent className="divide-y">
              {[
                { n: "Mustafa Bhai", e: "admin@fmbratangarh.org", r: "Admin" },
                { n: "Anwar Sheikh", e: "store@fmbratangarh.org", r: "Operator" },
                { n: "Salim Khan", e: "kitchen@fmbratangarh.org", r: "Operator" },
              ].map((u) => (
                <div key={u.e} className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9"><AvatarFallback className="bg-primary text-primary-foreground text-xs">{u.n.slice(0,2).toUpperCase()}</AvatarFallback></Avatar>
                    <div>
                      <p className="text-sm font-medium">{u.n}</p>
                      <p className="text-xs text-muted-foreground">{u.e}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={u.r === "Admin" ? "text-primary border-primary/30" : ""}>{u.r}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="theme" className="mt-6 grid gap-4 md:grid-cols-3">
          {[
            { n: "Primary", c: "#274230" },
            { n: "Secondary", c: "#4D6A52" },
            { n: "Accent Gold", c: "#D4AF37" },
          ].map((t) => (
            <Card key={t.n} className="shadow-soft">
              <CardContent className="flex items-center gap-4 p-5">
                <div className="h-14 w-14 rounded-xl" style={{ background: t.c }} />
                <div>
                  <p className="text-sm font-semibold">{t.n}</p>
                  <p className="font-mono text-xs text-muted-foreground">{t.c}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="notify" className="mt-6">
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Notification Preferences</CardTitle></CardHeader>
            <CardContent className="divide-y">
              {["Payment received", "Low stock alerts", "Pending cheques", "Monthly invoice generation", "Donation received"].map((n) => (
                <div key={n} className="flex items-center justify-between py-3">
                  <p className="text-sm">{n}</p>
                  <Switch defaultChecked />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="mt-6 grid gap-4 md:grid-cols-2">
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Backup</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">Last backup: 12 Nov 2025, 03:00 AM</p>
              <Button className="gap-1.5"><Database className="h-4 w-4" /> Backup Now</Button>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardHeader><CardTitle className="text-base">Restore</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">Upload a .sql or .zip backup file to restore.</p>
              <Input type="file" />
              <Button variant="outline">Restore</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input defaultValue={value} />
    </div>
  );
}
