import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { StatusBadge } from "@/components/common/StatusBadge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { employees, type Employee } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/employees")({
  component: EmployeesPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  name: z.string().trim().min(2, "Name is required").max(80),
  role: z.string().trim().min(2, "Role is required"),
  mobile: z.string().trim().min(7, "Mobile is required").max(20),
  joining: z.string().min(1, "Joining date is required"),
  salary: z.coerce.number().min(0, "Salary cannot be negative"),
  status: z.enum(["Active", "On Leave", "Resigned"]),
}) as unknown as z.ZodType<Employee>;

const fields: FieldConfig<Employee>[] = [
  { name: "name", label: "Full Name", colSpan: 2 },
  { name: "role", label: "Role", type: "select", options: [
    { label: "Head Cook", value: "Head Cook" },
    { label: "Asst. Cook", value: "Asst. Cook" },
    { label: "Delivery", value: "Delivery" },
    { label: "Manager", value: "Manager" },
    { label: "Store Keeper", value: "Store Keeper" },
    { label: "Cleaner", value: "Cleaner" },
  ]},
  { name: "status", label: "Status", type: "select", options: [
    { label: "Active", value: "Active" },
    { label: "On Leave", value: "On Leave" },
    { label: "Resigned", value: "Resigned" },
  ]},
  { name: "mobile", label: "Mobile", type: "tel" },
  { name: "joining", label: "Joining Date", type: "date" },
  { name: "salary", label: "Monthly Salary (₹)", type: "number", colSpan: 2 },
];

const empty: Employee = {
  id: "",
  name: "",
  role: "Delivery",
  mobile: "",
  joining: new Date().toISOString().slice(0, 10),
  salary: 12000,
  status: "Active",
};

function EmployeesPage() {
  const columns: Column<Employee>[] = [
    {
      key: "name", header: "Employee",
      render: (r) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9"><AvatarFallback className="bg-secondary/20 text-secondary text-xs">{r.name.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
          <div>
            <p className="font-medium">{r.name}</p>
            <p className="text-xs text-muted-foreground">{r.role}</p>
          </div>
        </div>
      ),
      accessor: (r) => r.name,
    },
    { key: "mobile", header: "Mobile", accessor: (r) => r.mobile },
    { key: "joining", header: "Joining", accessor: (r) => r.joining },
    { key: "salary", header: "Salary", align: "right", render: (r) => inr(r.salary), accessor: (r) => r.salary },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, accessor: (r) => r.status },
  ];
  return (
    <CrudResourcePage<Employee>
      title="Employees"
      subtitle="Kitchen, delivery and admin staff."
      seed={employees}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="Add Employee"
      entityLabel="Employee"
      idPrefix="E"
    />
  );
}
