import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import { PageHeader } from "@/components/common/PageHeader";
import { StatCard } from "@/components/common/StatCard";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatusBadge } from "@/components/common/StatusBadge";
import { FormModal, type FieldConfig } from "@/components/common/FormModal";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Eye, Printer, CheckSquare, Clock, XCircle } from "lucide-react";
import {
  chequeStore,
  addCheque,
  updateCheque,
  removeCheque,
  type ChequeRecord,
  type ChequeStatus,
} from "@/lib/stores/cheques";
import { queueNotification } from "@/lib/stores/notifications";
import { inr } from "@/lib/format";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/banking/cheques")({
  component: ChequesPage,
});

type FormRow = {
  id?: string;
  chequeNo: string;
  issueDate: string;
  depositDate?: string;
  clearDate?: string;
  bank: string;
  branch?: string;
  party: string;
  ledger?: string;
  amount: number;
  type: "Issued" | "Received";
  status: ChequeStatus;
  reference?: string;
  remarks?: string;
};

const chequeSchema = z.object({
  id: z.string().optional(),
  chequeNo: z.string().trim().regex(/^\d{4,10}$/, "Cheque number must be 4-10 digits"),
  issueDate: z.string().min(1, "Issue date required"),
  depositDate: z.string().optional().or(z.literal("")),
  clearDate: z.string().optional().or(z.literal("")),
  bank: z.string().trim().min(2, "Bank required"),
  branch: z.string().optional().or(z.literal("")),
  party: z.string().trim().min(2, "Party required"),
  ledger: z.string().optional().or(z.literal("")),
  amount: z.coerce.number().positive("Amount must be > 0"),
  type: z.enum(["Issued", "Received"]),
  status: z.enum(["Issued", "Deposited", "Cleared", "Pending", "Returned", "Cancelled"]),
  reference: z.string().optional().or(z.literal("")),
  remarks: z.string().optional().or(z.literal("")),
}) as unknown as z.ZodType<FormRow>;

const fields: FieldConfig<FormRow>[] = [
  { name: "chequeNo", label: "Cheque Number" },
  { name: "issueDate", label: "Issue Date", type: "date" },
  { name: "depositDate", label: "Deposit Date", type: "date" },
  { name: "clearDate", label: "Clear Date", type: "date" },
  { name: "bank", label: "Bank", type: "select", options: [
    { label: "SBI", value: "SBI" },
    { label: "HDFC", value: "HDFC" },
    { label: "ICICI", value: "ICICI" },
    { label: "Axis Bank", value: "Axis Bank" },
    { label: "BOB", value: "BOB" },
  ]},
  { name: "branch", label: "Branch", placeholder: "Ratangarh" },
  { name: "party", label: "Party (Payer / Payee)", colSpan: 2 },
  { name: "ledger", label: "Ledger", placeholder: "Supplier Payments / Member Collections" },
  { name: "amount", label: "Amount (₹)", type: "number" },
  { name: "type", label: "Type", type: "select", options: [
    { label: "Received", value: "Received" },
    { label: "Issued", value: "Issued" },
  ]},
  { name: "status", label: "Status", type: "select", options: [
    { label: "Issued", value: "Issued" },
    { label: "Deposited", value: "Deposited" },
    { label: "Cleared", value: "Cleared" },
    { label: "Pending", value: "Pending" },
    { label: "Returned", value: "Returned" },
    { label: "Cancelled", value: "Cancelled" },
  ]},
  { name: "reference", label: "Reference No", placeholder: "UTR / Voucher" },
  { name: "remarks", label: "Remarks", type: "textarea", colSpan: 2 },
];

const empty: FormRow = {
  chequeNo: "",
  issueDate: new Date().toISOString().slice(0, 10),
  bank: "SBI",
  branch: "Ratangarh",
  party: "",
  ledger: "",
  amount: 1000,
  type: "Received",
  status: "Pending",
  reference: "",
  remarks: "",
};

function ChequesPage() {
  const items = chequeStore.useStore();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ChequeRecord | null>(null);
  const [deleting, setDeleting] = useState<ChequeRecord | null>(null);
  const [viewing, setViewing] = useState<ChequeRecord | null>(null);

  const stats = useMemo(() => ({
    pending: items.filter((c) => c.status === "Pending" || c.status === "Issued").length,
    cleared: items.filter((c) => c.status === "Cleared").length,
    returned: items.filter((c) => c.status === "Returned").length,
    total: items.length,
  }), [items]);

  const handleSubmit = (values: FormRow) => {
    if (editing) {
      const prevStatus = editing.status;
      updateCheque(editing.id, values);
      if (values.status !== prevStatus) {
        if (values.status === "Cleared") {
          queueNotification({
            event: "Cheque Cleared",
            channel: "SMS",
            recipient: values.party,
            phone: "+91 9812345000",
            message: `Cheque no. ${values.chequeNo} for ₹${values.amount.toLocaleString("en-IN")} has been cleared.`,
            reference: `CHQ ${values.chequeNo}`,
          });
        } else if (values.status === "Returned") {
          queueNotification({
            event: "Cheque Returned",
            channel: "SMS",
            recipient: values.party,
            phone: "+91 9812345000",
            message: `Cheque no. ${values.chequeNo} for ₹${values.amount.toLocaleString("en-IN")} has been returned. Please issue a replacement.`,
            reference: `CHQ ${values.chequeNo}`,
          });
        } else if (values.status === "Deposited") {
          queueNotification({
            event: "Cheque Deposited",
            channel: "WhatsApp",
            recipient: values.party,
            phone: "+91 9812345000",
            message: `Cheque no. ${values.chequeNo} for ₹${values.amount.toLocaleString("en-IN")} has been deposited to ${values.bank}.`,
            reference: `CHQ ${values.chequeNo}`,
          });
        }
      }
    } else {
      addCheque({ ...values, allocations: [] });
      toast.success("Cheque added to register");
    }
  };

  const columns: Column<ChequeRecord>[] = [
    { key: "chequeNo", header: "Cheque No", render: (r) => <span className="font-mono font-semibold">{r.chequeNo}</span>, accessor: (r) => r.chequeNo },
    { key: "issueDate", header: "Issue", accessor: (r) => r.issueDate },
    { key: "clearDate", header: "Clear", accessor: (r) => r.clearDate ?? "—" },
    { key: "party", header: "Party", accessor: (r) => r.party },
    { key: "bank", header: "Bank", accessor: (r) => r.bank },
    { key: "type", header: "Type", render: (r) => <Badge variant="outline" className={r.type === "Received" ? "text-success" : "text-info"}>{r.type}</Badge>, accessor: (r) => r.type },
    { key: "allocations", header: "Split", align: "center",
      render: (r) => r.allocations.length ? <Badge variant="outline">{r.allocations.length}</Badge> : "—",
      accessor: (r) => r.allocations.length },
    { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-semibold tabular-nums">{inr(r.amount)}</span>, accessor: (r) => r.amount },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, accessor: (r) => r.status },
    {
      key: "__actions", header: "", align: "right",
      render: (r) => (
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setViewing(r)} aria-label="View"><Eye className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => window.print()} aria-label="Print"><Printer className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(r); setFormOpen(true); }} aria-label="Edit"><Pencil className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeleting(r)} aria-label="Delete"><Trash2 className="h-4 w-4" /></Button>
        </div>
      ),
    },
  ];

  const defaultsForForm: FormRow = editing
    ? {
        id: editing.id,
        chequeNo: editing.chequeNo,
        issueDate: editing.issueDate,
        depositDate: editing.depositDate ?? "",
        clearDate: editing.clearDate ?? "",
        bank: editing.bank,
        branch: editing.branch ?? "",
        party: editing.party,
        ledger: editing.ledger ?? "",
        amount: editing.amount,
        type: editing.type,
        status: editing.status,
        reference: editing.reference ?? "",
        remarks: editing.remarks ?? "",
      }
    : empty;

  return (
    <div>
      <PageHeader
        title="Cheque Register"
        subtitle="All issued and received cheques with clearance status, splits and reconciliation links."
        actions={
          <Button className="gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="h-4 w-4" /> Add Cheque
          </Button>
        }
      />
      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <StatCard label="Total Cheques" value={String(stats.total)} icon={CheckSquare} tone="default" />
        <StatCard label="Pending / Issued" value={String(stats.pending)} icon={Clock} tone="warning" />
        <StatCard label="Cleared" value={String(stats.cleared)} icon={CheckSquare} tone="success" />
        <StatCard label="Returned" value={String(stats.returned)} icon={XCircle} tone="destructive" />
      </div>
      <DataTable data={items} columns={columns} exportFilename="cheque-register" pageSize={12} />

      <FormModal<FormRow>
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit Cheque" : "Add Cheque"}
        description="All cheque fields are captured. Splits are added from Payment / Expense modules."
        fields={fields}
        schema={chequeSchema}
        defaultValues={defaultsForForm}
        submitLabel={editing ? "Update" : "Create"}
        onSubmit={handleSubmit}
      />

      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="Delete Cheque?"
        description={`Cheque ${deleting?.chequeNo} will be removed from the register.`}
        onConfirm={() => { if (deleting) { removeCheque(deleting.id); toast.success("Cheque removed"); } setDeleting(null); }}
      />

      <Dialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Cheque {viewing?.chequeNo}</DialogTitle>
            <DialogDescription>{viewing?.bank} · {viewing?.branch}</DialogDescription>
          </DialogHeader>
          {viewing && (
            <div className="space-y-3 text-sm">
              <Row label="Party" value={viewing.party} />
              <Row label="Ledger" value={viewing.ledger ?? "—"} />
              <Row label="Type" value={viewing.type} />
              <Row label="Status" value={viewing.status} />
              <Row label="Issue Date" value={viewing.issueDate} />
              <Row label="Deposit Date" value={viewing.depositDate ?? "—"} />
              <Row label="Clear Date" value={viewing.clearDate ?? "—"} />
              <Row label="Amount" value={inr(viewing.amount)} />
              <Row label="Reference" value={viewing.reference ?? "—"} />
              {viewing.allocations.length > 0 && (
                <div>
                  <p className="mt-2 text-xs font-semibold uppercase text-muted-foreground">Split allocations</p>
                  <ul className="mt-1 space-y-1">
                    {viewing.allocations.map((a, i) => (
                      <li key={i} className="flex justify-between rounded border px-3 py-1.5">
                        <span>{a.label} <span className="text-xs text-muted-foreground">({a.refType})</span></span>
                        <span className="font-medium tabular-nums">{inr(a.amount)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {viewing.remarks && <p className="mt-2 text-xs text-muted-foreground">Remarks: {viewing.remarks}</p>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
