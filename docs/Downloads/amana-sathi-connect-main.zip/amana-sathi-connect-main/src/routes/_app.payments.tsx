import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { Badge } from "@/components/ui/badge";
import { payments, families, type Payment } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/payments")({
  component: PaymentsPage,
});

const modeStyle: Record<string, string> = {
  Cash: "bg-gold/15 text-gold-foreground border-gold/30",
  Cheque: "bg-info/15 text-info border-info/30",
  "Bank Transfer": "bg-primary/10 text-primary border-primary/20",
  UPI: "bg-success/15 text-success border-success/30",
};

const schema = z.object({
  id: z.string().optional().default(""),
  date: z.string().min(1, "Date is required"),
  receipt: z.string().trim().min(2, "Receipt number is required").max(40),
  family: z.string().trim().min(2, "Family is required"),
  mode: z.enum(["Cash", "Cheque", "Bank Transfer", "UPI"]),
  reference: z.string().trim().max(60).default("-"),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
}) as unknown as z.ZodType<Payment>;

const familyOptions = Array.from(new Set(families.map((f) => f.head))).map((n) => ({ label: n, value: n }));

const fields: FieldConfig<Payment>[] = [
  { name: "receipt", label: "Receipt No", placeholder: "RCP/8001" },
  { name: "date", label: "Date", type: "date" },
  { name: "family", label: "Family", type: "select", options: familyOptions, colSpan: 2 },
  { name: "mode", label: "Mode", type: "select", options: [
    { label: "Cash", value: "Cash" },
    { label: "Cheque", value: "Cheque" },
    { label: "Bank Transfer", value: "Bank Transfer" },
    { label: "UPI", value: "UPI" },
  ]},
  { name: "reference", label: "Reference", placeholder: "Cheque / UPI / Txn ID" },
  { name: "amount", label: "Amount (₹)", type: "number", colSpan: 2 },
];

const empty: Payment = {
  id: "",
  date: new Date().toISOString().slice(0, 10),
  receipt: "",
  family: familyOptions[0]?.value ?? "",
  mode: "Cash",
  reference: "-",
  amount: 500,
};

const columns: Column<Payment>[] = [
  { key: "receipt", header: "Receipt", render: (r) => <span className="font-mono">{r.receipt}</span>, accessor: (r) => r.receipt },
  { key: "date", header: "Date", accessor: (r) => r.date },
  { key: "family", header: "Family", accessor: (r) => r.family },
  {
    key: "mode", header: "Mode",
    render: (r) => <Badge variant="outline" className={`rounded-full ${modeStyle[r.mode]}`}>{r.mode}</Badge>,
    accessor: (r) => r.mode,
  },
  { key: "reference", header: "Reference", accessor: (r) => r.reference },
  { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-semibold text-success">{inr(r.amount)}</span>, accessor: (r) => r.amount },
];

function PaymentsPage() {
  return (
    <CrudResourcePage<Payment>
      title="Payments"
      subtitle="Received payments across all modes with printable receipts."
      seed={payments}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="Receive Payment"
      entityLabel="Payment"
      idPrefix="PMT"
    />
  );
}
