import { createFileRoute } from "@tanstack/react-router";
import { ResourcePage } from "@/components/common/ResourcePage";
import { StatusBadge } from "@/components/common/StatusBadge";
import { employees } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";

type SalaryRow = { id: string; name: string; role: string; days: number; basic: number; deductions: number; net: number; status: string };

export const Route = createFileRoute("/_app/employees/salary")({
  component: () => {
    const rows: SalaryRow[] = employees.map((e, i) => ({
      id: `S-${i}`,
      name: e.name,
      role: e.role,
      days: 26 + (i % 5),
      basic: e.salary,
      deductions: i % 3 === 0 ? 500 : 0,
      net: e.salary - (i % 3 === 0 ? 500 : 0),
      status: i % 4 === 0 ? "Pending" : "Paid",
    }));
    const columns: Column<SalaryRow>[] = [
      { key: "name", header: "Employee", render: (r) => <div><p className="font-medium">{r.name}</p><p className="text-xs text-muted-foreground">{r.role}</p></div>, accessor: (r) => r.name },
      { key: "days", header: "Days", align: "center", accessor: (r) => r.days },
      { key: "basic", header: "Basic", align: "right", render: (r) => inr(r.basic), accessor: (r) => r.basic },
      { key: "deductions", header: "Deductions", align: "right", render: (r) => inr(r.deductions), accessor: (r) => r.deductions },
      { key: "net", header: "Net Pay", align: "right", render: (r) => <span className="font-semibold">{inr(r.net)}</span>, accessor: (r) => r.net },
      { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, accessor: (r) => r.status },
    ];
    return <ResourcePage title="Salary Register" subtitle="Monthly salary computation and payment status." data={rows} columns={columns} addLabel="Process Payroll" />;
  },
});
