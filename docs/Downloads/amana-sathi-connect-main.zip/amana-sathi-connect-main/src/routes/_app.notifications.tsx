import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { StatCard } from "@/components/common/StatCard";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatusBadge } from "@/components/common/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  notificationStore,
  markSent,
  cancelNotification,
  retryNotification,
  removeNotification,
  type AppNotification,
} from "@/lib/stores/notifications";
import { BellRing, MessageSquare, CheckCircle2, XCircle, Send, RotateCcw, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/notifications")({
  component: NotificationsPage,
});

function NotificationsPage() {
  const items = notificationStore.useStore();

  const stats = useMemo(() => {
    return {
      queued: items.filter((n) => n.status === "Queued").length,
      sent: items.filter((n) => n.status === "Sent").length,
      failed: items.filter((n) => n.status === "Failed").length,
      total: items.length,
    };
  }, [items]);

  const columns: Column<AppNotification>[] = [
    {
      key: "createdAt", header: "Time",
      accessor: (r) => r.createdAt,
      render: (r) => (
        <span className="text-xs text-muted-foreground">
          {new Date(r.createdAt).toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" })}
        </span>
      ),
    },
    {
      key: "event", header: "Event",
      accessor: (r) => r.event,
      render: (r) => <Badge variant="outline" className="font-medium">{r.event}</Badge>,
    },
    {
      key: "channel", header: "Channel",
      accessor: (r) => r.channel,
      render: (r) => (
        <span className="inline-flex items-center gap-1.5 text-xs">
          <MessageSquare className="h-3.5 w-3.5 text-info" />
          {r.channel}
        </span>
      ),
    },
    { key: "recipient", header: "Recipient", accessor: (r) => r.recipient,
      render: (r) => (
        <div>
          <p className="font-medium">{r.recipient}</p>
          <p className="font-mono text-xs text-muted-foreground">{r.phone}</p>
        </div>
      ),
    },
    {
      key: "message", header: "Message",
      accessor: (r) => r.message,
      render: (r) => <p className="max-w-md truncate text-xs text-muted-foreground">{r.message}</p>,
    },
    { key: "reference", header: "Ref", accessor: (r) => r.reference ?? "—" },
    { key: "status", header: "Status", accessor: (r) => r.status, render: (r) => <StatusBadge status={r.status} /> },
    {
      key: "__actions", header: "", align: "right",
      render: (r) => (
        <div className="flex justify-end gap-1">
          {r.status === "Queued" && (
            <Button size="icon" variant="ghost" className="h-7 w-7 text-success" onClick={() => markSent(r.id)} aria-label="Mark sent">
              <Send className="h-3.5 w-3.5" />
            </Button>
          )}
          {(r.status === "Failed" || r.status === "Cancelled") && (
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => retryNotification(r.id)} aria-label="Retry">
              <RotateCcw className="h-3.5 w-3.5" />
            </Button>
          )}
          {r.status === "Queued" && (
            <Button size="icon" variant="ghost" className="h-7 w-7 text-warning" onClick={() => cancelNotification(r.id)} aria-label="Cancel">
              <XCircle className="h-3.5 w-3.5" />
            </Button>
          )}
          <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => removeNotification(r.id)} aria-label="Delete">
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      ),
    },
  ];

  const sendAllQueued = () => {
    items.filter((n) => n.status === "Queued").forEach((n) => markSent(n.id));
  };

  return (
    <div>
      <PageHeader
        title="Notifications"
        subtitle="Outgoing SMS & WhatsApp messages triggered by ERP events. API-ready — wire a provider in production."
        actions={
          <Button className="gap-1.5" onClick={sendAllQueued} disabled={stats.queued === 0}>
            <Send className="h-4 w-4" /> Send Queued ({stats.queued})
          </Button>
        }
      />
      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <StatCard label="Total Notifications" value={String(stats.total)} icon={BellRing} tone="default" />
        <StatCard label="Queued" value={String(stats.queued)} icon={MessageSquare} tone="warning" />
        <StatCard label="Sent" value={String(stats.sent)} icon={CheckCircle2} tone="success" />
        <StatCard label="Failed" value={String(stats.failed)} icon={XCircle} tone="destructive" />
      </div>
      <DataTable data={items} columns={columns} exportFilename="notifications" pageSize={15} />
    </div>
  );
}
