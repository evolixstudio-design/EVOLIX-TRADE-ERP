import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/common/StatusBadge";
import { bankAccounts } from "@/lib/mock-data";
import { inr } from "@/lib/format";

export const Route = createFileRoute("/_app/banking/reconciliation")({
  component: () => (
    <div>
      <PageHeader
        title="Bank Reconciliation"
        subtitle="Match bank statement entries with your books."
        actions={<Button>Import Statement</Button>}
      />
      <div className="grid gap-4 md:grid-cols-4">
        {bankAccounts.map((b) => (
          <Card key={b.id} className="shadow-soft">
            <CardContent className="p-5">
              <p className="text-sm font-semibold">{b.name}</p>
              <p className="text-xs text-muted-foreground">{b.bank}</p>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Book</span><span className="tabular-nums">{inr(b.balance)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Statement</span><span className="tabular-nums">{inr(b.balance - 1200)}</span></div>
                <div className="flex justify-between border-t pt-2 font-semibold"><span>Difference</span><span className="tabular-nums text-warning">{inr(1200)}</span></div>
              </div>
              <div className="mt-3"><StatusBadge status="Pending" /></div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  ),
});
