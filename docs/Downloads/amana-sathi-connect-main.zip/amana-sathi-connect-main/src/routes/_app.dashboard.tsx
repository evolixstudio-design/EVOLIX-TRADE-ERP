import { createFileRoute } from "@tanstack/react-router";
import {
  UtensilsCrossed,
  Wallet,
  TrendingUp,
  Users,
  Landmark,
  Coins,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  FileText,
  HandHeart,
  ShoppingCart,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Line,
  LineChart,
  Area,
  AreaChart,
  Legend,
} from "recharts";
import { PageHeader } from "@/components/common/PageHeader";
import { StatCard } from "@/components/common/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/common/StatusBadge";
import { activities, monthlyCollection, distributionTrend, outstandingTrend, payments, stock, cheques } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const lowStock = stock.filter((s) => s.qty <= s.min * 1.2);
  const pendingCheques = cheques.filter((c) => c.status === "Pending");

  return (
    <div>
      <PageHeader
        title="Dashboard"
        subtitle="Overview of today's operations, collections and community activity."
        actions={
          <>
            <Button variant="outline" className="gap-1.5"><FileText className="h-4 w-4" /> Reports</Button>
            <Button className="gap-1.5"><Plus className="h-4 w-4" /> Quick entry</Button>
          </>
        }
      />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Today's Distribution" value="108 thali" icon={UtensilsCrossed} hint="+6 vs yesterday" tone="gold" />
        <StatCard label="Today's Collection" value={inr(18450)} icon={Wallet} hint="12 payments" tone="success" />
        <StatCard label="Monthly Collection" value={inr(208000)} icon={TrendingUp} hint="Nov 2025" tone="info" />
        <StatCard label="Monthly Expenses" value={inr(152000)} icon={ArrowDownRight} hint="26 entries" tone="warning" />
        <StatCard label="Bank Balance" value={inr(1813000)} icon={Landmark} hint="4 accounts" tone="default" />
        <StatCard label="Cash Balance" value={inr(24500)} icon={Coins} hint="Kitchen cash" tone="gold" />
        <StatCard label="Outstanding" value={inr(87500)} icon={AlertTriangle} hint="14 families" tone="destructive" />
        <StatCard label="Active Families" value="428 / 480" icon={Users} hint="52 inactive" tone="success" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Income vs Expenses</CardTitle>
            <Badge variant="outline" className="gap-1"><ArrowUpRight className="h-3 w-3 text-success" /> +12.4%</Badge>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={monthlyCollection}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" tickFormatter={(v) => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => inr(v)} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
                <Legend />
                <Bar dataKey="collection" fill="var(--primary)" radius={[6, 6, 0, 0]} name="Collection" />
                <Bar dataKey="expense" fill="var(--gold)" radius={[6, 6, 0, 0]} name="Expense" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader><CardTitle className="text-base">Outstanding Trend</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={outstandingTrend}>
                <defs>
                  <linearGradient id="outs" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--destructive)" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="var(--destructive)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                <XAxis dataKey="week" className="text-xs" />
                <YAxis className="text-xs" tickFormatter={(v) => `${v / 1000}k`} />
                <Tooltip formatter={(v: number) => inr(v)} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
                <Area type="monotone" dataKey="outstanding" stroke="var(--destructive)" strokeWidth={2} fill="url(#outs)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader><CardTitle className="text-base">Daily Distribution (last 14 days)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={distributionTrend}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                <XAxis dataKey="day" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
                <Legend />
                <Line type="monotone" dataKey="thalis" stroke="var(--primary)" strokeWidth={2.5} dot={{ r: 3 }} name="Thalis" />
                <Line type="monotone" dataKey="extra" stroke="var(--gold)" strokeWidth={2} dot={{ r: 3 }} name="Extra" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader><CardTitle className="text-base">Quick Actions</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            {[
              { l: "Add Family", i: Users, to: "/members" },
              { l: "Receive Payment", i: Wallet, to: "/payments" },
              { l: "New Invoice", i: FileText, to: "/invoices" },
              { l: "Add Donation", i: HandHeart, to: "/donations" },
              { l: "Purchase Entry", i: ShoppingCart, to: "/purchases" },
              { l: "Mark Thali", i: UtensilsCrossed, to: "/thali/distribution" },
            ].map((q) => (
              <Link
                key={q.l}
                to={q.to}
                className="group flex flex-col items-start gap-2 rounded-xl border bg-card p-4 transition-all hover:border-primary hover:shadow-soft"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground">
                  <q.i className="h-4 w-4" />
                </span>
                <span className="text-sm font-medium">{q.l}</span>
              </Link>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Recent Transactions</CardTitle>
            <Link to="/payments" className="text-xs text-primary hover:underline">View all</Link>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y">
              {payments.slice(0, 6).map((p) => (
                <li key={p.id} className="flex items-center justify-between px-6 py-3 hover:bg-muted/40">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-success/10 text-success">
                      <ArrowUpRight className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{p.family}</p>
                      <p className="text-xs text-muted-foreground">{p.mode} · {p.receipt}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold tabular-nums">{inr(p.amount)}</p>
                    <p className="text-xs text-muted-foreground">{p.date}</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader><CardTitle className="text-base">Recent Activity</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {activities.slice(0, 6).map((a) => (
              <div key={a.id} className="flex gap-3 text-sm">
                <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />
                <div className="min-w-0">
                  <p className="truncate">
                    <span className="font-medium">{a.user}</span> {a.action}{" "}
                    <span className="text-muted-foreground">— {a.target}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">{a.at}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card className="shadow-soft">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" /> Low Stock Alerts
            </CardTitle>
            <Link to="/stock" className="text-xs text-primary hover:underline">View stock</Link>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y">
              {lowStock.slice(0, 6).map((s) => (
                <li key={s.id} className="flex items-center justify-between px-6 py-3">
                  <div>
                    <p className="text-sm font-medium">{s.name}</p>
                    <p className="text-xs text-muted-foreground">{s.category} · min {s.min} {s.unit}</p>
                  </div>
                  <StatusBadge status={s.qty <= s.min ? "Unpaid" : "Partial"} />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Pending Cheques</CardTitle>
            <Link to="/banking/cheques" className="text-xs text-primary hover:underline">View all</Link>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y">
              {pendingCheques.slice(0, 6).map((c) => (
                <li key={c.id} className="flex items-center justify-between px-6 py-3">
                  <div>
                    <p className="text-sm font-medium">{c.party}</p>
                    <p className="text-xs text-muted-foreground">Chq {c.chequeNo} · {c.bank}</p>
                  </div>
                  <p className="text-sm font-semibold tabular-nums">{inr(c.amount)}</p>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
