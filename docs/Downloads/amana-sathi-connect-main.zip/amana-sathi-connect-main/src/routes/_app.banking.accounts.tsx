import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Landmark, Pencil, Trash2 } from "lucide-react";
import { bankAccounts, type BankAccount } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import { FormModal, type FieldConfig } from "@/components/common/FormModal";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { useCrud } from "@/hooks/use-crud";

export const Route = createFileRoute("/_app/banking/accounts")({
  component: BankAccountsPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  name: z.string().trim().min(2, "Account label is required").max(60),
  bank: z.string().trim().min(2, "Bank name is required").max(80),
  accountNo: z.string().trim().regex(/^\d{6,20}$/, "Account number must be 6-20 digits"),
  ifsc: z.string().trim().regex(/^[A-Z]{4}0[A-Z0-9]{6}$/, "Invalid IFSC code"),
  branch: z.string().trim().min(2, "Branch is required").max(80),
  balance: z.coerce.number().min(0, "Balance cannot be negative"),
}) as unknown as z.ZodType<BankAccount>;

const fields: FieldConfig<BankAccount>[] = [
  { name: "name", label: "Account Label", placeholder: "FMB Main", colSpan: 2 },
  { name: "bank", label: "Bank Name", placeholder: "State Bank of India" },
  { name: "branch", label: "Branch", placeholder: "Ratangarh" },
  { name: "accountNo", label: "Account Number" },
  { name: "ifsc", label: "IFSC Code", placeholder: "SBIN0001234" },
  { name: "balance", label: "Opening Balance (₹)", type: "number", colSpan: 2 },
];

const empty: BankAccount = {
  id: "",
  name: "",
  bank: "",
  accountNo: "",
  ifsc: "",
  branch: "",
  balance: 0,
};

function BankAccountsPage() {
  const { items, create, update, remove } = useCrud<BankAccount>(bankAccounts, {
    idPrefix: "B",
    label: "Bank Account",
  });
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<BankAccount | null>(null);
  const [deleting, setDeleting] = useState<BankAccount | null>(null);

  return (
    <div>
      <PageHeader
        title="Bank Accounts"
        subtitle="All FMB bank accounts with live balances."
        actions={
          <Button className="gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="h-4 w-4" /> Add Account
          </Button>
        }
      />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {items.map((b) => (
          <Card key={b.id} className="group shadow-soft transition-shadow hover:shadow-elevated">
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary"><Landmark className="h-5 w-5" /></div>
                  <div>
                    <p className="font-semibold">{b.name}</p>
                    <p className="text-xs text-muted-foreground">{b.bank}</p>
                  </div>
                </div>
                <div className="flex opacity-0 transition-opacity group-hover:opacity-100">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditing(b); setFormOpen(true); }}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeleting(b)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
              <div className="mt-4 space-y-1 text-sm">
                <p className="text-muted-foreground">A/c No: <span className="font-mono text-foreground">{b.accountNo}</span></p>
                <p className="text-muted-foreground">IFSC: <span className="font-mono text-foreground">{b.ifsc}</span></p>
                <p className="text-muted-foreground">Branch: <span className="text-foreground">{b.branch}</span></p>
              </div>
              <div className="mt-4 border-t pt-3">
                <p className="text-xs uppercase text-muted-foreground">Balance</p>
                <p className="text-2xl font-semibold tabular-nums text-primary">{inr(b.balance)}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <FormModal<BankAccount>
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? "Edit Bank Account" : "New Bank Account"}
        fields={fields}
        schema={schema}
        defaultValues={editing ?? empty}
        submitLabel={editing ? "Update" : "Create"}
        onSubmit={(v) => (editing ? update(editing.id, v) : create(v))}
      />
      <ConfirmDialog
        open={!!deleting}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="Delete Bank Account?"
        description="This account will be removed. Existing transactions are not affected."
        onConfirm={() => {
          if (deleting) remove(deleting.id);
          setDeleting(null);
        }}
      />
    </div>
  );
}
