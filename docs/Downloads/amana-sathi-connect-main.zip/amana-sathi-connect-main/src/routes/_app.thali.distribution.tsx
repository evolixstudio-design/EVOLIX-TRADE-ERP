import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { StatCard } from "@/components/common/StatCard";
import { DataTable, type Column } from "@/components/common/DataTable";
import { StatusBadge } from "@/components/common/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, X, UtensilsCrossed, Users, Package, BellRing } from "lucide-react";
import { families } from "@/lib/mock-data";
import { dateFmt } from "@/lib/format";
import {
  attendanceStore,
  setAttendance,
  attendanceForDate,
  summarize,
} from "@/lib/stores/attendance";
import { queueNotification } from "@/lib/stores/notifications";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/thali/distribution")({
  component: DistributionPage,
});

type Row = {
  id: string;
  thaliNo: string;
  head: string;
  members: number;
  status: "Taken" | "Not Taken" | "Unmarked";
  remarks: string;
  markedAt: string;
  familyId: string;
  phone: string;
};

function DistributionPage() {
  const records = attendanceStore.useStore();
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));

  const rows = useMemo<Row[]>(() => {
    const day = attendanceForDate(records, date);
    return families.map((f) => {
      const rec = day.find((r) => r.familyId === f.id);
      return {
        id: `${date}-${f.id}`,
        thaliNo: f.thaliNo,
        head: f.head,
        members: f.members,
        status: rec ? rec.status : "Unmarked",
        remarks: rec?.remarks ?? "",
        markedAt: rec?.markedAt ? new Date(rec.markedAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }) : "—",
        familyId: f.id,
        phone: f.mobile,
      };
    });
  }, [records, date]);

  const stats = useMemo(() => summarize(records, date), [records, date]);

  const mark = (row: Row, status: "Taken" | "Not Taken") => {
    setAttendance(date, row.familyId, status);
    toast.success(`Marked ${status}`, { description: `${row.head} · ${row.thaliNo}` });
  };

  const sendReminders = () => {
    const unmarked = rows.filter((r) => r.status === "Unmarked");
    if (unmarked.length === 0) {
      toast.info("Every family is already marked for this date.");
      return;
    }
    unmarked.forEach((r) => {
      queueNotification({
        event: "Distribution Reminder",
        channel: "WhatsApp",
        recipient: r.head,
        phone: r.phone,
        message: `Assalamu Alaikum ${r.head}. Please confirm thali for ${date}. Reply YES to receive, NO to skip.`,
        reference: r.thaliNo,
      });
    });
    toast.success(`${unmarked.length} reminders queued`);
  };

  const columns: Column<Row>[] = [
    { key: "thaliNo", header: "Thali No", render: (r) => <span className="font-mono font-semibold">{r.thaliNo}</span>, accessor: (r) => r.thaliNo },
    { key: "head", header: "Head of Family", accessor: (r) => r.head },
    { key: "members", header: "Members", align: "center", accessor: (r) => r.members },
    { key: "markedAt", header: "Marked", accessor: (r) => r.markedAt },
    {
      key: "status", header: "Status",
      render: (r) => r.status === "Unmarked"
        ? <span className="text-xs text-muted-foreground">Unmarked</span>
        : <StatusBadge status={r.status === "Taken" ? "Delivered" : "Not Delivered"} />,
      accessor: (r) => r.status,
    },
    { key: "remarks", header: "Remarks", accessor: (r) => r.remarks || "—" },
    {
      key: "__actions", header: "", align: "right",
      render: (r) => (
        <div className="flex justify-end gap-1">
          <Button
            size="sm"
            variant={r.status === "Taken" ? "default" : "outline"}
            className={`h-8 gap-1 ${r.status === "Taken" ? "" : "text-success"}`}
            onClick={() => mark(r, "Taken")}
          >
            <Check className="h-3.5 w-3.5" /> Taken
          </Button>
          <Button
            size="sm"
            variant={r.status === "Not Taken" ? "destructive" : "outline"}
            className={`h-8 gap-1 ${r.status === "Not Taken" ? "" : "text-destructive"}`}
            onClick={() => mark(r, "Not Taken")}
          >
            <X className="h-3.5 w-3.5" /> Not Taken
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Daily Thali Distribution"
        subtitle={dateFmt(date)}
        actions={
          <>
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-[170px]"
            />
            <Button variant="outline" className="gap-1.5" onClick={sendReminders}>
              <BellRing className="h-4 w-4" /> Send Reminders
            </Button>
          </>
        }
      />
      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <StatCard label="Total Families" value={String(stats.total)} icon={UtensilsCrossed} tone="gold" />
        <StatCard label="Taken" value={String(stats.taken)} icon={Check} tone="success" hint={`${Math.round((stats.taken / stats.total) * 100)}%`} />
        <StatCard label="Not Taken" value={String(stats.notTaken)} icon={Package} tone="destructive" />
        <StatCard label="Unmarked" value={String(stats.unmarked)} icon={Users} tone="warning" />
      </div>
      <DataTable data={rows} columns={columns} exportFilename={`distribution-${date}`} />
    </div>
  );
}
