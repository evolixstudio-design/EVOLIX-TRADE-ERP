import { createFileRoute } from "@tanstack/react-router";
import { ResourcePage } from "@/components/common/ResourcePage";
import { Badge } from "@/components/ui/badge";
import { stock } from "@/lib/mock-data";
import { num } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";

type Movement = { id: string; date: string; item: string; type: "IN" | "OUT"; qty: number; unit: string; ref: string };

export const Route = createFileRoute("/_app/stock/movements")({
  component: () => {
    const rows: Movement[] = Array.from({ length: 40 }, (_, i) => {
      const it = stock[i % stock.length];
      return {
        id: `MV-${i}`,
        date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
        item: it.name,
        type: i % 3 === 0 ? "IN" : "OUT",
        qty: (i % 3 === 0 ? 20 : 3) + (i % 8),
        unit: it.unit,
        ref: i % 3 === 0 ? `PO-${100 + i}` : `CONS-${i}`,
      };
    });
    const columns: Column<Movement>[] = [
      { key: "date", header: "Date", accessor: (r) => r.date },
      { key: "item", header: "Item", accessor: (r) => r.item },
      { key: "type", header: "Type", render: (r) => <Badge variant="outline" className={r.type === "IN" ? "text-success border-success/30" : "text-destructive border-destructive/30"}>{r.type}</Badge>, accessor: (r) => r.type },
      { key: "qty", header: "Qty", align: "right", render: (r) => `${num(r.qty)} ${r.unit}`, accessor: (r) => r.qty },
      { key: "ref", header: "Reference", render: (r) => <span className="font-mono">{r.ref}</span>, accessor: (r) => r.ref },
    ];
    return <ResourcePage title="Stock Movements" subtitle="Inward purchases and outward kitchen consumption." data={rows} columns={columns} addLabel="Add Movement" />;
  },
});
