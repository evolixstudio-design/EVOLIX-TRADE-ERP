import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { StatusBadge } from "@/components/common/StatusBadge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { families, type Family } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/members")({
  component: MembersPage,
});

const familySchema = z.object({
  id: z.string().optional().default(""),
  its: z.string().trim().regex(/^\d{8}$/, "ITS must be an 8-digit number"),
  head: z.string().trim().min(2, "Head of family is required").max(100),
  father: z.string().trim().min(2, "Father's name is required").max(100),
  members: z.coerce.number().int().min(1, "At least 1 member").max(50),
  mobile: z.string().trim().min(7, "Mobile is required").max(20),
  whatsapp: z.string().trim().max(20).optional().or(z.literal("")).default(""),
  email: z.string().trim().email("Invalid email").max(255).or(z.literal("")).default(""),
  address: z.string().trim().min(2, "Address is required").max(200),
  city: z.string().trim().min(2).max(80),
  pin: z.string().trim().regex(/^\d{6}$/, "PIN must be 6 digits"),
  sabbeel: z.string().trim().max(30).default(""),
  thaliNo: z.string().trim().min(1, "Thali number is required").max(20),
  sector: z.string().trim().min(1, "Sector is required"),
  status: z.enum(["Active", "Inactive", "Suspended"]),
  startDate: z.string().min(1, "Start date is required"),
  outstanding: z.coerce.number().min(0).default(0),
  contribution: z.coerce.number().min(0, "Contribution must be positive"),
}) as unknown as z.ZodType<Family>;

const fields: FieldConfig<Family>[] = [
  { name: "head", label: "Head of Family", placeholder: "e.g. Mufaddalbhai Rangwala", colSpan: 2 },
  { name: "father", label: "Father's Name" },
  { name: "its", label: "ITS Number", placeholder: "8 digits" },
  { name: "thaliNo", label: "Thali No", placeholder: "T-101" },
  { name: "sabbeel", label: "Sabbeel No", placeholder: "SB-2001" },
  { name: "members", label: "Members", type: "number" },
  { name: "sector", label: "Sector", type: "select", options: [
    { label: "Sector A", value: "Sector A" },
    { label: "Sector B", value: "Sector B" },
    { label: "Sector C", value: "Sector C" },
    { label: "Sector D", value: "Sector D" },
    { label: "Sector E", value: "Sector E" },
  ]},
  { name: "status", label: "Status", type: "select", options: [
    { label: "Active", value: "Active" },
    { label: "Inactive", value: "Inactive" },
    { label: "Suspended", value: "Suspended" },
  ]},
  { name: "mobile", label: "Mobile", type: "tel", placeholder: "+91 9876543210" },
  { name: "whatsapp", label: "WhatsApp", type: "tel" },
  { name: "email", label: "Email", type: "email", colSpan: 2 },
  { name: "address", label: "Address", type: "textarea", colSpan: 2 },
  { name: "city", label: "City" },
  { name: "pin", label: "PIN Code" },
  { name: "startDate", label: "Start Date", type: "date" },
  { name: "contribution", label: "Monthly Contribution (₹)", type: "number" },
  { name: "outstanding", label: "Outstanding (₹)", type: "number" },
];

const emptyFamily: Family = {
  id: "",
  its: "",
  head: "",
  father: "",
  members: 1,
  mobile: "",
  whatsapp: "",
  email: "",
  address: "",
  city: "Ratangarh",
  pin: "331022",
  sabbeel: "",
  thaliNo: "",
  sector: "Sector A",
  status: "Active",
  startDate: new Date().toISOString().slice(0, 10),
  outstanding: 0,
  contribution: 1200,
};

const columns: Column<Family>[] = [
  {
    key: "head",
    header: "Head of Family",
    render: (r) => (
      <div className="flex items-center gap-3">
        <Avatar className="h-9 w-9">
          <AvatarFallback className="bg-primary/10 text-primary text-xs">{r.head.slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-medium text-foreground">{r.head}</p>
          <p className="text-xs text-muted-foreground">S/o {r.father}</p>
        </div>
      </div>
    ),
    accessor: (r) => r.head + " " + r.father,
  },
  { key: "its", header: "ITS", accessor: (r) => r.its },
  { key: "thaliNo", header: "Thali No", accessor: (r) => r.thaliNo },
  { key: "sector", header: "Sector", accessor: (r) => r.sector },
  { key: "members", header: "Members", align: "center", accessor: (r) => r.members },
  { key: "mobile", header: "Mobile", accessor: (r) => r.mobile },
  { key: "contribution", header: "Contribution", align: "right", render: (r) => inr(r.contribution), accessor: (r) => r.contribution },
  {
    key: "outstanding",
    header: "Outstanding",
    align: "right",
    render: (r) => (
      <span className={r.outstanding > 0 ? "font-semibold text-destructive" : "text-muted-foreground"}>
        {inr(r.outstanding)}
      </span>
    ),
    accessor: (r) => r.outstanding,
  },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, accessor: (r) => r.status },
];

function MembersPage() {
  return (
    <CrudResourcePage<Family>
      title="Members"
      subtitle="All registered families with their ITS, thali and contribution details."
      seed={families}
      columns={columns}
      fields={fields}
      schema={familySchema}
      emptyValues={emptyFamily}
      addLabel="Add Family"
      entityLabel="Family"
      idPrefix="FAM"
    />
  );
}
