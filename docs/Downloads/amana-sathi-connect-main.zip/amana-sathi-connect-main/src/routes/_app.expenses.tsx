import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { Badge } from "@/components/ui/badge";
import { expenses, type Expense } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/expenses")({
  component: ExpensesPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  date: z.string().min(1, "Date is required"),
  category: z.string().trim().min(2, "Category is required"),
  particulars: z.string().trim().min(2, "Particulars are required").max(200),
  paidTo: z.string().trim().min(2, "Paid to is required").max(100),
  mode: z.string().trim().min(2, "Mode is required"),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
}) as unknown as z.ZodType<Expense>;

const fields: FieldConfig<Expense>[] = [
  { name: "date", label: "Date", type: "date" },
  { name: "category", label: "Category", type: "select", options: [
    { label: "Salary", value: "Salary" },
    { label: "Electricity", value: "Electricity" },
    { label: "Gas", value: "Gas" },
    { label: "Transport", value: "Transport" },
    { label: "Maintenance", value: "Maintenance" },
    { label: "Misc", value: "Misc" },
  ]},
  { name: "particulars", label: "Particulars", type: "textarea", colSpan: 2 },
  { name: "paidTo", label: "Paid To", placeholder: "Vendor / staff" },
  { name: "mode", label: "Mode", type: "select", options: [
    { label: "Cash", value: "Cash" },
    { label: "Cheque", value: "Cheque" },
    { label: "Bank", value: "Bank" },
  ]},
  { name: "amount", label: "Amount (₹)", type: "number", colSpan: 2 },
];

const empty: Expense = {
  id: "",
  date: new Date().toISOString().slice(0, 10),
  category: "Misc",
  particulars: "",
  paidTo: "",
  mode: "Cash",
  amount: 500,
};

function ExpensesPage() {
  const columns: Column<Expense>[] = [
    { key: "date", header: "Date", accessor: (r) => r.date },
    { key: "category", header: "Category", render: (r) => <Badge variant="outline">{r.category}</Badge>, accessor: (r) => r.category },
    { key: "particulars", header: "Particulars", accessor: (r) => r.particulars },
    { key: "paidTo", header: "Paid To", accessor: (r) => r.paidTo },
    { key: "mode", header: "Mode", accessor: (r) => r.mode },
    { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-semibold text-destructive">{inr(r.amount)}</span>, accessor: (r) => r.amount },
  ];
  return (
    <CrudResourcePage<Expense>
      title="Expenses"
      subtitle="Salary, utilities, transport and other operating expenses."
      seed={expenses}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="Add Expense"
      entityLabel="Expense"
      idPrefix="EXP"
    />
  );
}
