import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { Badge } from "@/components/ui/badge";
import { suppliers, type Supplier } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/suppliers")({
  component: SuppliersPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  name: z.string().trim().min(2, "Supplier name is required").max(100),
  contact: z.string().trim().min(7, "Contact is required").max(30),
  gstin: z.string().trim().max(20).default("-"),
  category: z.string().trim().min(2, "Category is required").max(40),
  outstanding: z.coerce.number().min(0, "Cannot be negative").default(0),
}) as unknown as z.ZodType<Supplier>;

const fields: FieldConfig<Supplier>[] = [
  { name: "name", label: "Supplier Name", placeholder: "e.g. Marwar Grocery Traders", colSpan: 2 },
  { name: "category", label: "Category", type: "select", options: [
    { label: "Grocery", value: "Grocery" },
    { label: "Vegetables", value: "Vegetables" },
    { label: "Milk", value: "Milk" },
    { label: "Gas", value: "Gas" },
    { label: "Flour", value: "Flour" },
    { label: "Oil", value: "Oil" },
    { label: "Cleaning", value: "Cleaning" },
    { label: "Disposable", value: "Disposable" },
    { label: "Other", value: "Other" },
  ]},
  { name: "contact", label: "Contact", type: "tel", placeholder: "+91 9876500000" },
  { name: "gstin", label: "GSTIN", placeholder: "08AABCM1234K1Z5", colSpan: 2 },
  { name: "outstanding", label: "Outstanding (₹)", type: "number", colSpan: 2 },
];

const empty: Supplier = {
  id: "",
  name: "",
  contact: "",
  gstin: "-",
  category: "Grocery",
  outstanding: 0,
};

function SuppliersPage() {
  const columns: Column<Supplier>[] = [
    { key: "name", header: "Supplier", render: (r) => <span className="font-medium">{r.name}</span>, accessor: (r) => r.name },
    { key: "category", header: "Category", render: (r) => <Badge variant="outline">{r.category}</Badge>, accessor: (r) => r.category },
    { key: "contact", header: "Contact", accessor: (r) => r.contact },
    { key: "gstin", header: "GSTIN", render: (r) => <span className="font-mono text-xs">{r.gstin}</span>, accessor: (r) => r.gstin },
    { key: "outstanding", header: "Outstanding", align: "right", render: (r) => <span className={r.outstanding > 0 ? "font-semibold text-destructive" : "text-muted-foreground"}>{inr(r.outstanding)}</span>, accessor: (r) => r.outstanding },
  ];
  return (
    <CrudResourcePage<Supplier>
      title="Suppliers"
      subtitle="Grocery, gas, milk, vegetables and utility vendors."
      seed={suppliers}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="Add Supplier"
      entityLabel="Supplier"
      idPrefix="SUP"
    />
  );
}
