import { createFileRoute } from "@tanstack/react-router";
import { ResourcePage } from "@/components/common/ResourcePage";
import { bankAccounts } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";

type Transfer = { id: string; date: string; from: string; to: string; ref: string; amount: number };

export const Route = createFileRoute("/_app/banking/transfers")({
  component: () => {
    const rows: Transfer[] = Array.from({ length: 12 }, (_, i) => ({
      id: `TR-${i}`,
      date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
      from: bankAccounts[i % bankAccounts.length].name,
      to: bankAccounts[(i + 1) % bankAccounts.length].name,
      ref: `NEFT/${100000 + i * 7}`,
      amount: 5000 + (i * 1250),
    }));
    const columns: Column<Transfer>[] = [
      { key: "date", header: "Date", accessor: (r) => r.date },
      { key: "ref", header: "Reference", render: (r) => <span className="font-mono">{r.ref}</span>, accessor: (r) => r.ref },
      { key: "from", header: "From Account", accessor: (r) => r.from },
      { key: "to", header: "To Account", accessor: (r) => r.to },
      { key: "amount", header: "Amount", align: "right", render: (r) => inr(r.amount), accessor: (r) => r.amount },
    ];
    return <ResourcePage title="Bank Transfers" subtitle="Inter-account transfers and NEFT/RTGS entries." data={rows} columns={columns} addLabel="New Transfer" />;
  },
});
