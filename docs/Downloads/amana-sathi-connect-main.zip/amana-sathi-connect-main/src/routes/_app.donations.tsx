import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { CrudResourcePage } from "@/components/common/CrudResourcePage";
import { Badge } from "@/components/ui/badge";
import { donations, type Donation } from "@/lib/mock-data";
import { inr } from "@/lib/format";
import type { Column } from "@/components/common/DataTable";
import type { FieldConfig } from "@/components/common/FormModal";

export const Route = createFileRoute("/_app/donations")({
  component: DonationsPage,
});

const schema = z.object({
  id: z.string().optional().default(""),
  date: z.string().min(1, "Date is required"),
  donor: z.string().trim().min(2, "Donor name is required").max(100),
  mode: z.enum(["Cash", "Cheque", "Online", "Anonymous"]),
  purpose: z.string().trim().min(2, "Purpose is required").max(80),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
}) as unknown as z.ZodType<Donation>;

const fields: FieldConfig<Donation>[] = [
  { name: "date", label: "Date", type: "date" },
  { name: "mode", label: "Mode", type: "select", options: [
    { label: "Cash", value: "Cash" },
    { label: "Cheque", value: "Cheque" },
    { label: "Online", value: "Online" },
    { label: "Anonymous", value: "Anonymous" },
  ]},
  { name: "donor", label: "Donor Name", placeholder: "Full name or Anonymous", colSpan: 2 },
  { name: "purpose", label: "Purpose", type: "select", options: [
    { label: "Thali Sponsor", value: "Thali Sponsor" },
    { label: "Ashara Sponsor", value: "Ashara Sponsor" },
    { label: "Kitchen Upgrade", value: "Kitchen Upgrade" },
    { label: "Milad Sponsor", value: "Milad Sponsor" },
    { label: "General", value: "General" },
  ]},
  { name: "amount", label: "Amount (₹)", type: "number" },
];

const empty: Donation = {
  id: "",
  date: new Date().toISOString().slice(0, 10),
  donor: "",
  mode: "Cash",
  purpose: "General",
  amount: 1100,
};

function DonationsPage() {
  const columns: Column<Donation>[] = [
    { key: "date", header: "Date", accessor: (r) => r.date },
    { key: "donor", header: "Donor", render: (r) => <span className="font-medium">{r.donor}</span>, accessor: (r) => r.donor },
    { key: "purpose", header: "Purpose", render: (r) => <Badge variant="outline" className="text-gold">{r.purpose}</Badge>, accessor: (r) => r.purpose },
    { key: "mode", header: "Mode", accessor: (r) => r.mode },
    { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-semibold text-success">{inr(r.amount)}</span>, accessor: (r) => r.amount },
  ];
  return (
    <CrudResourcePage<Donation>
      title="Donations"
      subtitle="Community donations including sponsorships and Ashara contributions."
      seed={donations}
      columns={columns}
      fields={fields}
      schema={schema}
      emptyValues={empty}
      addLabel="Add Donation"
      entityLabel="Donation"
      idPrefix="DON"
    />
  );
}
