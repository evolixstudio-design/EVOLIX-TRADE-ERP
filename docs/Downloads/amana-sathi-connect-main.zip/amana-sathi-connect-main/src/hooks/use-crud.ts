import { useCallback, useState } from "react";
import { toast } from "sonner";

/**
 * Generic in-memory CRUD store for mock data.
 * Keeps records reactive within the current session so the UI updates
 * immediately after add / edit / delete. Ready to swap for API calls.
 */
export function useCrud<T extends { id: string }>(
  seed: T[],
  opts: {
    idPrefix?: string;
    label?: string;
    /** Optional derivation applied on every create / update (e.g. compute totals) */
    derive?: (row: T) => T;
  } = {},
) {
  const { idPrefix = "ID", label = "Record", derive } = opts;
  const [items, setItems] = useState<T[]>(() => [...seed]);

  const create = useCallback(
    (values: Omit<T, "id"> & { id?: string }) => {
      const id =
        values.id ??
        `${idPrefix}-${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 900 + 100)}`;
      const row = { ...(values as T), id } as T;
      const finalRow = derive ? derive(row) : row;
      setItems((prev) => [finalRow, ...prev]);
      toast.success(`${label} created`);
      return finalRow;
    },
    [idPrefix, label, derive],
  );

  const bulkCreate = useCallback(
    (rows: Array<Omit<T, "id"> & { id?: string }>) => {
      const built: T[] = rows.map((values, i) => {
        const id =
          values.id ??
          `${idPrefix}-${Date.now().toString(36).toUpperCase()}${Math.floor(
            Math.random() * 900 + 100,
          )}${i}`;
        const row = { ...(values as T), id } as T;
        return derive ? derive(row) : row;
      });
      setItems((prev) => [...built, ...prev]);
      return built;
    },
    [idPrefix, derive],
  );


  const update = useCallback(
    (id: string, values: Partial<T>) => {
      setItems((prev) =>
        prev.map((r) => {
          if (r.id !== id) return r;
          const next = { ...r, ...values, id } as T;
          return derive ? derive(next) : next;
        }),
      );
      toast.success(`${label} updated`);
    },
    [label, derive],
  );

  const remove = useCallback(
    (id: string) => {
      setItems((prev) => prev.filter((r) => r.id !== id));
      toast.success(`${label} deleted`);
    },
    [label],
  );

  return { items, setItems, create, bulkCreate, update, remove };
}
