import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const map: Record<string, string> = {
  Active: "bg-success/15 text-success border-success/30",
  Delivered: "bg-success/15 text-success border-success/30",
  Paid: "bg-success/15 text-success border-success/30",
  Cleared: "bg-success/15 text-success border-success/30",
  Inactive: "bg-muted text-muted-foreground border-border",
  "Not Delivered": "bg-destructive/10 text-destructive border-destructive/30",
  Suspended: "bg-destructive/10 text-destructive border-destructive/30",
  Unpaid: "bg-destructive/10 text-destructive border-destructive/30",
  Overdue: "bg-destructive/10 text-destructive border-destructive/30",
  Bounced: "bg-destructive/10 text-destructive border-destructive/30",
  Resigned: "bg-destructive/10 text-destructive border-destructive/30",
  Partial: "bg-warning/20 text-warning-foreground border-warning/30",
  Pending: "bg-warning/20 text-warning-foreground border-warning/30",
  "On Leave": "bg-warning/20 text-warning-foreground border-warning/30",
  Extra: "bg-gold/20 text-gold-foreground border-gold/40",
  Guest: "bg-gold/20 text-gold-foreground border-gold/40",
  Donation: "bg-info/15 text-info border-info/30",
  Deposited: "bg-info/15 text-info border-info/30",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <Badge variant="outline" className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium", map[status] ?? "bg-muted text-muted-foreground border-border")}>
      {status}
    </Badge>
  );
}
