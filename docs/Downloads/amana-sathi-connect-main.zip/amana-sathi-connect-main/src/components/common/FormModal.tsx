import { useEffect, type ReactNode } from "react";
import { useForm, type DefaultValues, type FieldValues, type Path } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { ZodType } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

export type FieldConfig<T extends FieldValues = FieldValues> = {
  name: Path<T>;
  label: string;
  type?: "text" | "number" | "date" | "textarea" | "select" | "email" | "tel";
  placeholder?: string;
  options?: { label: string; value: string }[];
  colSpan?: 1 | 2;
  step?: string;
  description?: string;
  /** Hide when this predicate returns false. Receives the current form values. */
  visible?: (values: T) => boolean;
};

export type FormModalProps<T extends FieldValues> = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  fields: FieldConfig<T>[];
  schema: ZodType<T>;
  defaultValues: DefaultValues<T>;
  onSubmit: (values: T) => void;
  submitLabel?: string;
  footerExtras?: ReactNode;
};

export function FormModal<T extends FieldValues>({
  open,
  onOpenChange,
  title,
  description,
  fields,
  schema,
  defaultValues,
  onSubmit,
  submitLabel = "Save",
  footerExtras,
}: FormModalProps<T>) {
  const form = useForm<T>({
    resolver: zodResolver(schema as never) as never,
    defaultValues,
    mode: "onBlur",
  });

  // Reset when the modal opens with different defaults (edit vs new)
  useEffect(() => {
    if (open) form.reset(defaultValues);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, JSON.stringify(defaultValues)]);

  const watched = form.watch();
  const submit = form.handleSubmit((values) => {
    onSubmit(values);
    onOpenChange(false);
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {fields.map((f) => {
                if (f.visible && !f.visible(watched as T)) return null;
                return (
                  <FormField
                    key={String(f.name)}
                    control={form.control}
                    name={f.name}
                    render={({ field }) => (
                      <FormItem className={f.colSpan === 2 ? "sm:col-span-2" : ""}>
                        <FormLabel>{f.label}</FormLabel>
                        <FormControl>
                          {f.type === "textarea" ? (
                            <Textarea
                              placeholder={f.placeholder}
                              {...field}
                              value={(field.value ?? "") as string}
                            />
                          ) : f.type === "select" ? (
                            <Select
                              value={(field.value ?? "") as string}
                              onValueChange={field.onChange}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder={f.placeholder ?? "Select..."} />
                              </SelectTrigger>
                              <SelectContent>
                                {f.options?.map((o) => (
                                  <SelectItem key={o.value} value={o.value}>
                                    {o.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <Input
                              type={f.type ?? "text"}
                              step={f.step}
                              placeholder={f.placeholder}
                              {...field}
                              value={(field.value ?? "") as string | number}
                              onChange={(e) => {
                                const v =
                                  f.type === "number"
                                    ? e.target.value === ""
                                      ? ""
                                      : Number(e.target.value)
                                    : e.target.value;
                                field.onChange(v);
                              }}
                            />
                          )}
                        </FormControl>
                        {f.description && (
                          <p className="text-xs text-muted-foreground">{f.description}</p>
                        )}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                );
              })}
            </div>
            <DialogFooter className="gap-2 sm:gap-2">
              {footerExtras}
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit">{submitLabel}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
