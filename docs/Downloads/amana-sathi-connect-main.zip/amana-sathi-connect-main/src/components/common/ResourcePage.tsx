import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { PageHeader } from "./PageHeader";
import { DataTable, type Column } from "./DataTable";

export function ResourcePage<T extends { id: string }>({
  title,
  subtitle,
  data,
  columns,
  addLabel = "New",
  extraActions,
}: {
  title: string;
  subtitle?: string;
  data: T[];
  columns: Column<T>[];
  addLabel?: string;
  extraActions?: ReactNode;
}) {
  return (
    <div>
      <PageHeader
        title={title}
        subtitle={subtitle}
        actions={
          <>
            {extraActions}
            <Button className="gap-1.5">
              <Plus className="h-4 w-4" /> {addLabel}
            </Button>
          </>
        }
      />
      <DataTable data={data} columns={columns} exportFilename={slugify(title)} />
    </div>
  );
}

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
