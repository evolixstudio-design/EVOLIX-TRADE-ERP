import { useMemo, useState, type ReactNode } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronLeft, ChevronRight, Search, Filter, Download, ChevronDown } from "lucide-react";


export type Column<T> = {
  key: string;
  header: string;
  className?: string;
  render?: (row: T) => ReactNode;
  accessor?: (row: T) => string | number;
  align?: "left" | "right" | "center";
};

export function DataTable<T extends { id: string }>({
  data,
  columns,
  searchable = true,
  filterable = true,
  pageSize = 10,
  toolbar,
  empty = "No records found",
  exportFilename = "export",
}: {
  data: T[];
  columns: Column<T>[];
  searchable?: boolean;
  filterable?: boolean;
  pageSize?: number;
  toolbar?: ReactNode;
  empty?: string;
  exportFilename?: string;
}) {
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    if (!q) return data;
    const s = q.toLowerCase();
    return data.filter((row) =>
      columns.some((c) => {
        const v = c.accessor ? c.accessor(row) : (row as Record<string, unknown>)[c.key];
        return String(v ?? "").toLowerCase().includes(s);
      }),
    );
  }, [q, data, columns]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const p = Math.min(page, totalPages);
  const rows = filtered.slice((p - 1) * pageSize, p * pageSize);

  const handleExport = (scope: "page" | "filtered") => {
    const exportRows = scope === "page" ? rows : filtered;
    if (exportRows.length === 0) return;
    const exportCols = columns.filter(
      (c) => c.key !== "actions" && !c.key.startsWith("__") && c.header,
    );
    const escape = (v: unknown) => {
      const s = v == null ? "" : String(v);
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const header = exportCols.map((c) => escape(c.header)).join(",");
    const body = exportRows
      .map((row) =>
        exportCols
          .map((c) => {
            const v = c.accessor
              ? c.accessor(row)
              : (row as Record<string, unknown>)[c.key];
            return escape(v);
          })
          .join(","),
      )
      .join("\n");
    const csv = `${header}\n${body}`;
    const blob = new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 10);
    const suffix = scope === "page" ? `page-${p}` : `all-${filtered.length}`;
    a.href = url;
    a.download = `${exportFilename}-${suffix}-${stamp}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };


  return (
    <div className="rounded-xl border bg-card shadow-soft">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b px-4 py-3">
        <div className="flex flex-1 items-center gap-2">
          {searchable && (
            <div className="relative w-full max-w-xs">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={q}
                onChange={(e) => {
                  setQ(e.target.value);
                  setPage(1);
                }}
                className="pl-8"
              />
            </div>
          )}
          {filterable && (
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-4 w-4" />
              Filters
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          {toolbar}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                disabled={filtered.length === 0}
              >
                <Download className="h-4 w-4" />
                Export CSV
                <ChevronDown className="h-3.5 w-3.5 opacity-70" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Export as CSV</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => handleExport("page")}
                disabled={rows.length === 0}
              >
                Current page ({rows.length})
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => handleExport("filtered")}
                disabled={filtered.length === 0}
              >
                All filtered rows ({filtered.length})
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

        </div>
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/40 hover:bg-muted/40">
              {columns.map((c) => (
                <TableHead
                  key={c.key}
                  className={`text-xs font-semibold uppercase tracking-wide text-muted-foreground ${
                    c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : ""
                  } ${c.className ?? ""}`}
                >
                  {c.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-32 text-center text-sm text-muted-foreground">
                  {empty}
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => (
                <TableRow key={row.id} className="hover:bg-muted/30">
                  {columns.map((c) => {
                    const content = c.render
                      ? c.render(row)
                      : (c.accessor ? c.accessor(row) : ((row as Record<string, unknown>)[c.key] as ReactNode)) as ReactNode;
                    return (
                      <TableCell
                        key={c.key}
                        className={`text-sm ${c.align === "right" ? "text-right tabular-nums" : c.align === "center" ? "text-center" : ""} ${c.className ?? ""}`}
                      >
                        {content}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-between border-t px-4 py-3 text-xs text-muted-foreground">
        <span>
          Showing {rows.length === 0 ? 0 : (p - 1) * pageSize + 1}-{(p - 1) * pageSize + rows.length} of {filtered.length}
        </span>
        <div className="flex items-center gap-1">
          <Button variant="outline" size="icon" className="h-7 w-7" disabled={p === 1} onClick={() => setPage(p - 1)}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="px-2 font-medium text-foreground">
            {p} / {totalPages}
          </span>
          <Button variant="outline" size="icon" className="h-7 w-7" disabled={p === totalPages} onClick={() => setPage(p + 1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
