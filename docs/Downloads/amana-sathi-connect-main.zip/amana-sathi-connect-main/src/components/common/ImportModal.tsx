import { useMemo, useRef, useState, type ChangeEvent } from "react";
import type { FieldValues } from "react-hook-form";
import type { ZodType } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Upload, FileText, CheckCircle2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import type { FieldConfig } from "./FormModal";

const NONE = "__none__";

/** Minimal CSV parser supporting quoted fields, escaped quotes and CRLF. */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let inQuotes = false;
  const t = text.replace(/\r\n?/g, "\n");
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (inQuotes) {
      if (ch === '"') {
        if (t[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else cur += ch;
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      row.push(cur);
      cur = "";
    } else if (ch === "\n") {
      row.push(cur);
      rows.push(row);
      row = [];
      cur = "";
    } else cur += ch;
  }
  if (cur.length > 0 || row.length > 0) {
    row.push(cur);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

function autoMatch(fieldName: string, headers: string[]): string {
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
  const target = norm(fieldName);
  const found = headers.find((h) => norm(h) === target);
  if (found) return found;
  const partial = headers.find((h) => norm(h).includes(target) || target.includes(norm(h)));
  return partial ?? NONE;
}

export type ImportModalProps<T extends FieldValues> = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entityLabel?: string;
  fields: FieldConfig<T>[];
  schema: ZodType<T>;
  onImport: (rows: T[]) => void;
};

export function ImportModal<T extends FieldValues>({
  open,
  onOpenChange,
  entityLabel = "Record",
  fields,
  schema,
  onImport,
}: ImportModalProps<T>) {
  const [csvText, setCsvText] = useState("");
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const parsed = useMemo(() => (csvText.trim() ? parseCsv(csvText) : []), [csvText]);
  const headers = parsed[0] ?? [];
  const dataRows = parsed.slice(1);

  const reset = () => {
    setCsvText("");
    setMapping({});
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setCsvText(text);
    const rows = parseCsv(text);
    const hdrs = rows[0] ?? [];
    const auto: Record<string, string> = {};
    fields.forEach((f) => {
      auto[String(f.name)] = autoMatch(String(f.name), hdrs);
      if (auto[String(f.name)] === NONE) {
        const byLabel = autoMatch(f.label, hdrs);
        if (byLabel !== NONE) auto[String(f.name)] = byLabel;
      }
    });
    setMapping(auto);
  };

  const validation = useMemo(() => {
    if (dataRows.length === 0) return { valid: [] as T[], errors: [] as { row: number; message: string }[] };
    const valid: T[] = [];
    const errors: { row: number; message: string }[] = [];
    const headerIndex: Record<string, number> = {};
    headers.forEach((h, i) => (headerIndex[h] = i));
    dataRows.forEach((r, idx) => {
      const obj: Record<string, unknown> = {};
      fields.forEach((f) => {
        const src = mapping[String(f.name)];
        if (!src || src === NONE) return;
        const col = headerIndex[src];
        if (col == null) return;
        const raw = (r[col] ?? "").trim();
        if (raw === "") return;
        obj[String(f.name)] = raw;
      });
      const result = schema.safeParse(obj);
      if (result.success) valid.push(result.data);
      else {
        const first = result.error.issues[0];
        errors.push({
          row: idx + 2, // +2 = header + 1-based
          message: `${first.path.join(".") || "row"}: ${first.message}`,
        });
      }
    });
    return { valid, errors };
  }, [dataRows, headers, mapping, fields, schema]);

  const doImport = () => {
    if (validation.valid.length === 0) {
      toast.error("No valid rows to import");
      return;
    }
    onImport(validation.valid);
    toast.success(
      `Imported ${validation.valid.length} ${entityLabel.toLowerCase()}${validation.valid.length === 1 ? "" : "s"}` +
        (validation.errors.length ? ` (${validation.errors.length} skipped)` : ""),
    );
    reset();
    onOpenChange(false);
  };

  const downloadTemplate = () => {
    const csv = fields.map((f) => f.label).join(",") + "\n";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${entityLabel.toLowerCase()}-template.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) reset();
        onOpenChange(o);
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Import {entityLabel}s from CSV</DialogTitle>
          <DialogDescription>
            Upload or paste CSV, map columns to fields, then import validated rows.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,text/csv"
              onChange={handleFile}
              className="hidden"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-4 w-4" /> Choose CSV
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="gap-1.5"
              onClick={downloadTemplate}
            >
              <FileText className="h-4 w-4" /> Download template
            </Button>
            {csvText && (
              <Button type="button" variant="ghost" size="sm" onClick={reset}>
                Clear
              </Button>
            )}
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Or paste CSV content
            </label>
            <Textarea
              rows={4}
              placeholder="name,email,amount&#10;Ali,ali@example.com,500"
              value={csvText}
              onChange={(e) => {
                setCsvText(e.target.value);
                const rows = parseCsv(e.target.value);
                const hdrs = rows[0] ?? [];
                if (hdrs.length) {
                  const auto: Record<string, string> = {};
                  fields.forEach((f) => {
                    auto[String(f.name)] = autoMatch(String(f.name), hdrs);
                    if (auto[String(f.name)] === NONE) {
                      const byLabel = autoMatch(f.label, hdrs);
                      if (byLabel !== NONE) auto[String(f.name)] = byLabel;
                    }
                  });
                  setMapping(auto);
                }
              }}
              className="font-mono text-xs"
            />
          </div>

          {headers.length > 0 && (
            <div>
              <h4 className="mb-2 text-sm font-semibold">Column mapping</h4>
              <div className="grid gap-3 sm:grid-cols-2">
                {fields.map((f) => (
                  <div key={String(f.name)} className="space-y-1">
                    <label className="text-xs font-medium text-muted-foreground">
                      {f.label} <span className="font-mono text-[10px]">({String(f.name)})</span>
                    </label>
                    <Select
                      value={mapping[String(f.name)] ?? NONE}
                      onValueChange={(v) =>
                        setMapping((m) => ({ ...m, [String(f.name)]: v }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select column..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={NONE}>— Skip —</SelectItem>
                        {headers.map((h) => (
                          <SelectItem key={h} value={h}>
                            {h}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            </div>
          )}

          {dataRows.length > 0 && (
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <Badge variant="outline" className="gap-1 border-success/40 text-success">
                  <CheckCircle2 className="h-3 w-3" /> {validation.valid.length} valid
                </Badge>
                {validation.errors.length > 0 && (
                  <Badge variant="outline" className="gap-1 border-destructive/40 text-destructive">
                    <AlertCircle className="h-3 w-3" /> {validation.errors.length} invalid
                  </Badge>
                )}
                <span className="text-xs text-muted-foreground">
                  ({dataRows.length} row{dataRows.length === 1 ? "" : "s"} parsed)
                </span>
              </div>

              {validation.errors.length > 0 && (
                <ScrollArea className="h-32 rounded-md border bg-muted/30 p-2">
                  <ul className="space-y-1 text-xs">
                    {validation.errors.slice(0, 50).map((e, i) => (
                      <li key={i} className="font-mono text-destructive">
                        Row {e.row}: {e.message}
                      </li>
                    ))}
                    {validation.errors.length > 50 && (
                      <li className="text-muted-foreground">
                        …and {validation.errors.length - 50} more
                      </li>
                    )}
                  </ul>
                </ScrollArea>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-2">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            type="button"
            onClick={doImport}
            disabled={validation.valid.length === 0}
          >
            Import {validation.valid.length > 0 ? `(${validation.valid.length})` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
