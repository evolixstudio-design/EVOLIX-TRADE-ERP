import { useState, type ReactNode } from "react";
import type { FieldValues, DefaultValues } from "react-hook-form";
import type { ZodType } from "zod";
import { Button } from "@/components/ui/button";
import { Pencil, Plus, Trash2, Upload } from "lucide-react";
import { PageHeader } from "./PageHeader";
import { DataTable, type Column } from "./DataTable";
import { FormModal, type FieldConfig } from "./FormModal";
import { ConfirmDialog } from "./ConfirmDialog";
import { ImportModal } from "./ImportModal";
import { useCrud } from "@/hooks/use-crud";


export type CrudResourcePageProps<T extends { id: string } & FieldValues> = {
  title: string;
  subtitle?: string;
  seed: T[];
  columns: Column<T>[];
  fields: FieldConfig<T>[];
  schema: ZodType<T>;
  emptyValues: DefaultValues<T>;
  addLabel?: string;
  entityLabel?: string;
  idPrefix?: string;
  derive?: (row: T) => T;
  extraActions?: ReactNode;
  /** Optional: hide edit/delete row actions (e.g., read-only ledgers) */
  readOnly?: boolean;
};

export function CrudResourcePage<T extends { id: string } & FieldValues>({
  title,
  subtitle,
  seed,
  columns,
  fields,
  schema,
  emptyValues,
  addLabel,
  entityLabel = "Record",
  idPrefix = "ID",
  derive,
  extraActions,
  readOnly = false,
}: CrudResourcePageProps<T>) {
  const { items, create, bulkCreate, update, remove } = useCrud<T>(seed, {
    idPrefix,
    label: entityLabel,
    derive,
  });

  const [formOpen, setFormOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [editing, setEditing] = useState<T | null>(null);
  const [deleting, setDeleting] = useState<T | null>(null);


  const openNew = () => {
    setEditing(null);
    setFormOpen(true);
  };
  const openEdit = (row: T) => {
    setEditing(row);
    setFormOpen(true);
  };

  const actionColumn: Column<T> = {
    key: "__actions",
    header: "",
    align: "right",
    render: (row) => (
      <div className="flex justify-end gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => openEdit(row)}
          aria-label={`Edit ${entityLabel}`}
        >
          <Pencil className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-destructive hover:text-destructive"
          onClick={() => setDeleting(row)}
          aria-label={`Delete ${entityLabel}`}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    ),
  };

  const finalColumns = readOnly
    ? columns
    : [...columns.filter((c) => c.key !== "actions" && c.key !== "__actions"), actionColumn];

  return (
    <div>
      <PageHeader
        title={title}
        subtitle={subtitle}
        actions={
          <>
            {extraActions}
            {!readOnly && (
              <>
                <Button
                  variant="outline"
                  className="gap-1.5"
                  onClick={() => setImportOpen(true)}
                >
                  <Upload className="h-4 w-4" /> Import CSV
                </Button>
                <Button className="gap-1.5" onClick={openNew}>
                  <Plus className="h-4 w-4" /> {addLabel ?? `New ${entityLabel}`}
                </Button>
              </>
            )}
          </>

        }
      />
      <DataTable data={items} columns={finalColumns} exportFilename={title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")} />

      {!readOnly && (
        <FormModal<T>
          open={formOpen}
          onOpenChange={setFormOpen}
          title={editing ? `Edit ${entityLabel}` : `New ${entityLabel}`}
          description={
            editing
              ? `Update the details of this ${entityLabel.toLowerCase()}.`
              : `Fill in the details to create a new ${entityLabel.toLowerCase()}.`
          }
          fields={fields}
          schema={schema}
          defaultValues={(editing ?? emptyValues) as DefaultValues<T>}
          submitLabel={editing ? "Update" : "Create"}
          onSubmit={(values) => {
            if (editing) update(editing.id, values as Partial<T>);
            else create(values as Omit<T, "id">);
          }}
        />
      )}

      {!readOnly && (
        <ConfirmDialog
          open={!!deleting}
          onOpenChange={(o) => !o && setDeleting(null)}
          title={`Delete ${entityLabel}?`}
          description={`This ${entityLabel.toLowerCase()} will be permanently removed from the list.`}
          onConfirm={() => {
            if (deleting) remove(deleting.id);
            setDeleting(null);
          }}
        />
      )}

      {!readOnly && (
        <ImportModal<T>
          open={importOpen}
          onOpenChange={setImportOpen}
          entityLabel={entityLabel}
          fields={fields}
          schema={schema}
          onImport={(rows) => bulkCreate(rows as Array<Omit<T, "id">>)}
        />
      )}
    </div>
  );
}

