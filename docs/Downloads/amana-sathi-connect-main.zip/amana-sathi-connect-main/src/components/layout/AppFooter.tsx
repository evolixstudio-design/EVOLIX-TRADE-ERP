export function AppFooter() {
  return (
    <footer className="border-t bg-card/60 px-6 py-3 text-xs text-muted-foreground">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span>© {new Date().getFullYear()} Faizul Mawaid Burhaniya · Ratangarh. All rights reserved.</span>
        <span>v1.0.0 · Built for the Bohra community</span>
      </div>
    </footer>
  );
}
