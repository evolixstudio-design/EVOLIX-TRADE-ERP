import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Users,
  UtensilsCrossed,
  FileText,
  Wallet,
  BookOpen,
  Landmark,
  Coins,
  ShoppingCart,
  Truck,
  Package,
  HandHeart,
  Receipt,
  UserCog,
  BarChart3,
  Settings,
  ChevronRight,
  BellRing,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

type Item = { label: string; to: string; icon?: React.ComponentType<{ className?: string }> };
type Group = { label: string; icon: React.ComponentType<{ className?: string }>; items: Item[]; to?: string };

const nav: Group[] = [
  { label: "Dashboard", icon: LayoutDashboard, to: "/dashboard", items: [] },
  { label: "Members", icon: Users, to: "/members", items: [] },
  {
    label: "Thali",
    icon: UtensilsCrossed,
    items: [
      { label: "Daily Distribution", to: "/thali/distribution" },
      { label: "History", to: "/thali/history" },
      { label: "Calendar", to: "/thali/calendar" },
    ],
  },
  { label: "Invoices", icon: FileText, to: "/invoices", items: [] },
  { label: "Payments", icon: Wallet, to: "/payments", items: [] },
  {
    label: "Ledger",
    icon: BookOpen,
    items: [
      { label: "General", to: "/ledger/general" },
      { label: "Member", to: "/ledger/member" },
      { label: "Supplier", to: "/ledger/supplier" },
      { label: "Bank", to: "/ledger/bank" },
      { label: "Cash", to: "/ledger/cash" },
      { label: "Expense", to: "/ledger/expense" },
      { label: "Income", to: "/ledger/income" },
      { label: "Donation", to: "/ledger/donation" },
    ],
  },
  {
    label: "Banking",
    icon: Landmark,
    items: [
      { label: "Accounts", to: "/banking/accounts" },
      { label: "Cheques", to: "/banking/cheques" },
      { label: "Transfers", to: "/banking/transfers" },
      { label: "Reconciliation", to: "/banking/reconciliation" },
    ],
  },
  { label: "Cash Book", icon: Coins, to: "/cashbook", items: [] },
  { label: "Purchases", icon: ShoppingCart, to: "/purchases", items: [] },
  { label: "Suppliers", icon: Truck, to: "/suppliers", items: [] },
  {
    label: "Stock",
    icon: Package,
    items: [
      { label: "Inventory", to: "/stock" },
      { label: "Movements", to: "/stock/movements" },
    ],
  },
  { label: "Donations", icon: HandHeart, to: "/donations", items: [] },
  { label: "Expenses", icon: Receipt, to: "/expenses", items: [] },
  {
    label: "Employees",
    icon: UserCog,
    items: [
      { label: "Master", to: "/employees" },
      { label: "Attendance", to: "/employees/attendance" },
      { label: "Salary", to: "/employees/salary" },
    ],
  },
  { label: "Notifications", icon: BellRing, to: "/notifications", items: [] },
  { label: "Reports", icon: BarChart3, to: "/reports", items: [] },
  { label: "Settings", icon: Settings, to: "/settings", items: [] },
];

export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <aside className="hidden w-64 shrink-0 border-r border-sidebar-border bg-sidebar text-sidebar-foreground md:flex md:flex-col">
      <div className="flex items-center gap-3 border-b border-sidebar-border px-5 py-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold text-gold-foreground shadow-soft">
          <span className="font-serif text-lg font-bold">F</span>
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">FMB Ratangarh</p>
          <p className="truncate text-[11px] text-sidebar-foreground/70">Thali Management</p>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="space-y-0.5">
          {nav.map((g) => (
            <NavGroup key={g.label} group={g} pathname={pathname} />
          ))}
        </ul>
      </nav>
      <div className="border-t border-sidebar-border p-4">
        <div className="rounded-xl bg-sidebar-accent p-3 text-xs">
          <p className="font-semibold text-sidebar-accent-foreground">FMB v1.0</p>
          <p className="mt-0.5 text-sidebar-foreground/70">© 1447 H · Burhaniya</p>
        </div>
      </div>
    </aside>
  );
}

function NavGroup({ group, pathname }: { group: Group; pathname: string }) {
  const active = group.to
    ? pathname === group.to || pathname.startsWith(group.to + "/")
    : group.items.some((i) => pathname.startsWith(i.to));
  const [open, setOpen] = useState(active);
  const Icon = group.icon;

  if (group.items.length === 0 && group.to) {
    return (
      <li>
        <Link
          to={group.to}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
            active
              ? "bg-gold/15 text-gold font-medium"
              : "text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
          )}
        >
          <Icon className="h-4 w-4" />
          {group.label}
        </Link>
      </li>
    );
  }

  return (
    <li>
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
          active
            ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
            : "text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        )}
      >
        <Icon className="h-4 w-4" />
        <span className="flex-1 text-left">{group.label}</span>
        <ChevronRight className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-90")} />
      </button>
      {open && (
        <ul className="mt-0.5 space-y-0.5 pl-9">
          {group.items.map((item) => {
            const isActive = pathname === item.to;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "block rounded-lg px-3 py-1.5 text-[13px] transition-colors",
                    isActive
                      ? "bg-gold/15 text-gold font-medium"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                  )}
                >
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </li>
  );
}
