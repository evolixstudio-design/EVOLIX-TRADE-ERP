import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { Bell, Search, Sun, Moon, LogOut, User, Settings as SettingsIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const crumbLabels: Record<string, string> = {
  dashboard: "Dashboard",
  members: "Members",
  thali: "Thali",
  distribution: "Distribution",
  history: "History",
  calendar: "Calendar",
  invoices: "Invoices",
  payments: "Payments",
  ledger: "Ledger",
  general: "General",
  member: "Member",
  supplier: "Supplier",
  bank: "Bank",
  cash: "Cash",
  expense: "Expense",
  income: "Income",
  donation: "Donation",
  banking: "Banking",
  accounts: "Accounts",
  cheques: "Cheques",
  transfers: "Transfers",
  reconciliation: "Reconciliation",
  cashbook: "Cash Book",
  purchases: "Purchases",
  suppliers: "Suppliers",
  stock: "Stock",
  movements: "Movements",
  donations: "Donations",
  expenses: "Expenses",
  employees: "Employees",
  attendance: "Attendance",
  salary: "Salary",
  reports: "Reports",
  settings: "Settings",
};

export function AppHeader() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const parts = pathname.split("/").filter(Boolean);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-card/80 px-4 backdrop-blur md:px-6">
      <div className="hidden min-w-0 flex-1 items-center gap-2 text-sm md:flex">
        <Link to="/dashboard" className="text-muted-foreground hover:text-foreground">
          Home
        </Link>
        {parts.map((p, i) => (
          <span key={i} className="flex items-center gap-2">
            <span className="text-muted-foreground/50">/</span>
            <span className={i === parts.length - 1 ? "font-medium text-foreground" : "text-muted-foreground"}>
              {crumbLabels[p] ?? p}
            </span>
          </span>
        ))}
      </div>
      <div className="relative hidden max-w-md flex-1 md:block">
        <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search members, invoices, ITS…" className="pl-9" />
      </div>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" onClick={() => setDark((d) => !d)} aria-label="Toggle theme">
          {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-4 w-4" />
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-gold" />
            </Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-80 p-0">
            <div className="border-b p-3 text-sm font-semibold">Notifications</div>
            <ul className="max-h-72 divide-y overflow-y-auto text-sm">
              {[
                { t: "3 cheques pending clearance", s: "Banking · 5 min ago" },
                { t: "Low stock: Toor Dal (85 kg)", s: "Stock · 1 hr ago" },
                { t: "Payment received ₹1,200", s: "Members · 2 hr ago" },
                { t: "Ashara Sponsor donation ₹11,000", s: "Donation · today" },
              ].map((n, i) => (
                <li key={i} className="px-3 py-2 hover:bg-muted/50">
                  <p className="font-medium">{n.t}</p>
                  <p className="text-xs text-muted-foreground">{n.s}</p>
                </li>
              ))}
            </ul>
          </PopoverContent>
        </Popover>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="ml-1 flex items-center gap-2 rounded-full py-1 pl-1 pr-3 hover:bg-muted">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">MB</AvatarFallback>
              </Avatar>
              <div className="hidden text-left leading-tight sm:block">
                <p className="text-xs font-semibold">Mustafa Bhai</p>
                <p className="text-[11px] text-muted-foreground">Administrator</p>
              </div>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <User className="mr-2 h-4 w-4" /> Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate({ to: "/settings" })}>
              <SettingsIcon className="mr-2 h-4 w-4" /> Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate({ to: "/login" })}>
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
