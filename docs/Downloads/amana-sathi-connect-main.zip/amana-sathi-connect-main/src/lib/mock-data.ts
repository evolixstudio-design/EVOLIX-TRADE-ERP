// Mock data for FMB Ratangarh ERP. All arrays are API-shape ready.

export type Family = {
  id: string;
  its: string;
  head: string;
  father: string;
  members: number;
  mobile: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  pin: string;
  sabbeel: string;
  thaliNo: string;
  sector: string;
  status: "Active" | "Inactive" | "Suspended";
  startDate: string;
  outstanding: number;
  contribution: number;
};

const firstNames = ["Mufaddal", "Huzaifa", "Yusuf", "Taher", "Aliasger", "Shabbir", "Zainab", "Fatema", "Kulsum", "Insiya", "Hakimuddin", "Qutbuddin", "Idris", "Burhanuddin", "Mustafa", "Abbas", "Ammar", "Juzer", "Murtaza", "Saifuddin"];
const lastNames = ["Rangwala", "Kagalwala", "Lokhandwala", "Bootwala", "Colombowala", "Tinwala", "Bandukwala", "Poonawala", "Jamali", "Saifee", "Contractor", "Merchant"];
const sectors = ["Sector A", "Sector B", "Sector C", "Sector D", "Sector E"];

const rand = (n: number) => Math.floor(Math.random() * n);
const pick = <T>(a: T[]) => a[rand(a.length)];

export const families: Family[] = Array.from({ length: 48 }, (_, i) => {
  const head = `${pick(firstNames)}bhai ${pick(lastNames)}`;
  return {
    id: `FAM-${1000 + i}`,
    its: `${40000000 + rand(9999999)}`,
    head,
    father: `${pick(firstNames)}bhai ${pick(lastNames)}`,
    members: 2 + rand(7),
    mobile: `+91 9${rand(900000000) + 100000000}`,
    whatsapp: `+91 9${rand(900000000) + 100000000}`,
    email: `${head.split(" ")[0].toLowerCase()}${i}@example.com`,
    address: `${rand(200) + 1}, Bohra Mohalla`,
    city: "Ratangarh",
    pin: "331022",
    sabbeel: `SB-${2000 + i}`,
    thaliNo: `T-${100 + i}`,
    sector: pick(sectors),
    status: i % 11 === 0 ? "Inactive" : i % 17 === 0 ? "Suspended" : "Active",
    startDate: `2023-0${(i % 9) + 1}-15`,
    outstanding: i % 4 === 0 ? rand(15000) : 0,
    contribution: 1200 + rand(20) * 100,
  };
});

export type ThaliRow = {
  id: string;
  thaliNo: string;
  head: string;
  members: number;
  status: "Delivered" | "Not Delivered" | "Extra" | "Guest" | "Donation";
  remarks: string;
  time: string;
};

export const todayThali: ThaliRow[] = families.slice(0, 30).map((f, i) => ({
  id: `TD-${i}`,
  thaliNo: f.thaliNo,
  head: f.head,
  members: f.members,
  status: i % 13 === 0 ? "Not Delivered" : i % 7 === 0 ? "Extra" : i % 11 === 0 ? "Guest" : "Delivered",
  remarks: i % 13 === 0 ? "Family out of town" : "",
  time: `${11 + (i % 2)}:${(i * 3) % 60 < 10 ? "0" : ""}${(i * 3) % 60}`,
}));

export type Invoice = {
  id: string;
  no: string;
  date: string;
  family: string;
  thaliNo: string;
  amount: number;
  paid: number;
  balance: number;
  status: "Paid" | "Partial" | "Unpaid" | "Overdue";
};

export const invoices: Invoice[] = families.slice(0, 40).map((f, i) => {
  const amt = f.contribution;
  const paid = i % 4 === 0 ? 0 : i % 3 === 0 ? Math.floor(amt / 2) : amt;
  return {
    id: `INV-${5000 + i}`,
    no: `FMB/2025/${String(1000 + i).padStart(5, "0")}`,
    date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
    family: f.head,
    thaliNo: f.thaliNo,
    amount: amt,
    paid,
    balance: amt - paid,
    status: paid === 0 ? "Unpaid" : paid < amt ? "Partial" : "Paid",
  };
});

export type Payment = {
  id: string;
  date: string;
  receipt: string;
  family: string;
  mode: "Cash" | "Cheque" | "Bank Transfer" | "UPI";
  reference: string;
  amount: number;
};

export const payments: Payment[] = Array.from({ length: 36 }, (_, i) => ({
  id: `PMT-${3000 + i}`,
  date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
  receipt: `RCP/${8000 + i}`,
  family: families[i % families.length].head,
  mode: (["Cash", "Cheque", "Bank Transfer", "UPI"] as const)[i % 4],
  reference: i % 4 === 1 ? `CHQ-${100 + i}` : i % 4 === 3 ? `UPI-${Date.now()}${i}` : "-",
  amount: 500 + rand(30) * 200,
}));

export type LedgerEntry = {
  id: string;
  date: string;
  particulars: string;
  vch: string;
  debit: number;
  credit: number;
  balance: number;
};

export const ledger: LedgerEntry[] = (() => {
  let bal = 125000;
  return Array.from({ length: 40 }, (_, i) => {
    const debit = i % 3 === 0 ? rand(20000) : 0;
    const credit = i % 3 !== 0 ? rand(15000) : 0;
    bal = bal + debit - credit;
    return {
      id: `L-${i}`,
      date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
      particulars: pick(["Member Contribution", "Grocery Purchase", "Salary Paid", "Donation Received", "Gas Cylinder", "Electricity Bill", "Vegetable Purchase", "Bank Deposit"]),
      vch: `V-${1000 + i}`,
      debit,
      credit,
      balance: bal,
    };
  });
})();

export type Cheque = {
  id: string;
  chequeNo: string;
  date: string;
  party: string;
  bank: string;
  amount: number;
  type: "Issued" | "Received";
  status: "Pending" | "Cleared" | "Bounced" | "Deposited";
};

export const cheques: Cheque[] = Array.from({ length: 22 }, (_, i) => ({
  id: `CHQ-${i}`,
  chequeNo: `${100000 + i * 3}`,
  date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
  party: i % 2 === 0 ? families[i % families.length].head : pick(["Reliance Fresh", "Ratangarh Gas", "Marwar Traders"]),
  bank: pick(["SBI", "HDFC", "ICICI", "Axis Bank", "BOB"]),
  amount: 1000 + rand(50) * 500,
  type: i % 2 === 0 ? "Received" : "Issued",
  status: (["Pending", "Cleared", "Bounced", "Deposited"] as const)[i % 4],
}));

export type BankAccount = {
  id: string;
  name: string;
  bank: string;
  accountNo: string;
  ifsc: string;
  branch: string;
  balance: number;
};

export const bankAccounts: BankAccount[] = [
  { id: "B1", name: "FMB Main", bank: "State Bank of India", accountNo: "3421890034", ifsc: "SBIN0001234", branch: "Ratangarh", balance: 842500 },
  { id: "B2", name: "FMB Donation", bank: "HDFC Bank", accountNo: "5001234599", ifsc: "HDFC0000567", branch: "Ratangarh", balance: 315200 },
  { id: "B3", name: "FMB Kitchen", bank: "ICICI Bank", accountNo: "6789012345", ifsc: "ICIC0000891", branch: "Sardarshahar", balance: 128900 },
  { id: "B4", name: "FMB Reserve", bank: "Bank of Baroda", accountNo: "1122334455", ifsc: "BARB0RATANG", branch: "Ratangarh", balance: 526400 },
];

export type Supplier = {
  id: string;
  name: string;
  contact: string;
  gstin: string;
  category: string;
  outstanding: number;
};

export const suppliers: Supplier[] = [
  { id: "S1", name: "Marwar Grocery Traders", contact: "+91 9876500001", gstin: "08AABCM1234K1Z5", category: "Grocery", outstanding: 24500 },
  { id: "S2", name: "Ratangarh Vegetable Mandi", contact: "+91 9876500002", gstin: "-", category: "Vegetables", outstanding: 4200 },
  { id: "S3", name: "Ganga Milk Dairy", contact: "+91 9876500003", gstin: "08AAECD5678L1ZP", category: "Milk", outstanding: 8900 },
  { id: "S4", name: "Bharat Gas Agency", contact: "+91 9876500004", gstin: "08AAKFB9012M1Z2", category: "Gas", outstanding: 0 },
  { id: "S5", name: "Shree Ram Flour Mill", contact: "+91 9876500005", gstin: "08AASFS3456N1Z7", category: "Flour", outstanding: 12000 },
  { id: "S6", name: "Rajasthan Oil Depot", contact: "+91 9876500006", gstin: "08AAPCR7890P1Z9", category: "Oil", outstanding: 6700 },
  { id: "S7", name: "Sparkle Clean Supplies", contact: "+91 9876500007", gstin: "08AATCS1234Q1Z1", category: "Cleaning", outstanding: 1500 },
  { id: "S8", name: "Poonam Disposables", contact: "+91 9876500008", gstin: "-", category: "Disposable", outstanding: 0 },
];

export type Purchase = {
  id: string;
  billNo: string;
  date: string;
  supplier: string;
  items: number;
  amount: number;
  gst: number;
  total: number;
  status: "Paid" | "Pending" | "Partial";
};

export const purchases: Purchase[] = Array.from({ length: 24 }, (_, i) => {
  const amt = 2000 + rand(50) * 500;
  const gst = i % 3 === 0 ? Math.round(amt * 0.05) : 0;
  return {
    id: `PO-${i}`,
    billNo: `BILL/${2025}/${String(100 + i).padStart(4, "0")}`,
    date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
    supplier: pick(suppliers).name,
    items: 3 + rand(10),
    amount: amt,
    gst,
    total: amt + gst,
    status: (["Paid", "Pending", "Partial"] as const)[i % 3],
  };
});

export type StockItem = {
  id: string;
  name: string;
  category: string;
  unit: string;
  qty: number;
  min: number;
  rate: number;
  value: number;
  lastPurchase: string;
};

const stockDefs: [string, string, string, number, number, number][] = [
  ["Basmati Rice", "Grocery", "kg", 240, 100, 90],
  ["Toor Dal", "Grocery", "kg", 85, 50, 145],
  ["Wheat Flour", "Grocery", "kg", 320, 150, 42],
  ["Sunflower Oil", "Grocery", "ltr", 62, 30, 128],
  ["Onion", "Vegetables", "kg", 45, 20, 32],
  ["Potato", "Vegetables", "kg", 78, 25, 28],
  ["Tomato", "Vegetables", "kg", 22, 20, 40],
  ["Green Chilli", "Vegetables", "kg", 6, 5, 80],
  ["Cow Milk", "Milk", "ltr", 55, 30, 62],
  ["Curd", "Milk", "kg", 18, 10, 90],
  ["LPG Cylinder", "Gas", "pcs", 4, 2, 1150],
  ["Disposable Plate", "Disposable", "pcs", 850, 500, 3.5],
  ["Tissue Roll", "Disposable", "pcs", 42, 20, 25],
  ["Dish Wash Bar", "Cleaning", "pcs", 12, 10, 22],
  ["Floor Cleaner", "Cleaning", "ltr", 6, 5, 95],
  ["Sugar", "Grocery", "kg", 95, 40, 46],
  ["Salt", "Grocery", "kg", 40, 20, 22],
  ["Garam Masala", "Grocery", "kg", 4, 2, 380],
];

export const stock: StockItem[] = stockDefs.map(([name, cat, unit, qty, min, rate], i) => ({
  id: `SKU-${i}`,
  name,
  category: cat,
  unit,
  qty,
  min,
  rate,
  value: qty * rate,
  lastPurchase: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
}));

export type Donation = {
  id: string;
  date: string;
  donor: string;
  mode: "Cash" | "Cheque" | "Online" | "Anonymous";
  purpose: string;
  amount: number;
};

export const donations: Donation[] = Array.from({ length: 20 }, (_, i) => ({
  id: `DON-${i}`,
  date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
  donor: i % 7 === 0 ? "Anonymous" : pick(families).head,
  mode: (["Cash", "Cheque", "Online", "Anonymous"] as const)[i % 4],
  purpose: pick(["Thali Sponsor", "Ashara Sponsor", "Kitchen Upgrade", "General", "Milad Sponsor"]),
  amount: 500 + rand(100) * 100,
}));

export type Expense = {
  id: string;
  date: string;
  category: string;
  particulars: string;
  paidTo: string;
  mode: string;
  amount: number;
};

export const expenses: Expense[] = Array.from({ length: 28 }, (_, i) => ({
  id: `EXP-${i}`,
  date: `2025-11-${String((i % 28) + 1).padStart(2, "0")}`,
  category: pick(["Salary", "Electricity", "Gas", "Transport", "Maintenance", "Misc"]),
  particulars: pick(["Monthly wages", "Elec bill", "LPG refill", "Vegetable transport", "Kitchen repair", "Stationery"]),
  paidTo: pick(["Kitchen Staff", "RREC", "Bharat Gas", "Local Vendor", "Office Boy"]),
  mode: pick(["Cash", "Cheque", "Bank"]),
  amount: 400 + rand(80) * 100,
}));

export type Employee = {
  id: string;
  name: string;
  role: string;
  mobile: string;
  joining: string;
  salary: number;
  status: "Active" | "On Leave" | "Resigned";
};

export const employees: Employee[] = [
  { id: "E1", name: "Salim Khan", role: "Head Cook", mobile: "+91 9812345678", joining: "2021-04-01", salary: 22000, status: "Active" },
  { id: "E2", name: "Rashid Ali", role: "Asst. Cook", mobile: "+91 9812345679", joining: "2022-06-15", salary: 15000, status: "Active" },
  { id: "E3", name: "Firoz Sheikh", role: "Delivery", mobile: "+91 9812345680", joining: "2023-01-20", salary: 12000, status: "Active" },
  { id: "E4", name: "Kaleem Ansari", role: "Delivery", mobile: "+91 9812345681", joining: "2023-03-11", salary: 12000, status: "Active" },
  { id: "E5", name: "Mustafa Bhai", role: "Manager", mobile: "+91 9812345682", joining: "2020-09-01", salary: 28000, status: "Active" },
  { id: "E6", name: "Ismail Khan", role: "Cleaner", mobile: "+91 9812345683", joining: "2024-02-05", salary: 9000, status: "On Leave" },
  { id: "E7", name: "Anwar Sheikh", role: "Store Keeper", mobile: "+91 9812345684", joining: "2022-11-30", salary: 14000, status: "Active" },
];

export const cashBook = Array.from({ length: 15 }, (_, i) => ({
  id: `CB-${i}`,
  date: `2025-11-${String(i + 1).padStart(2, "0")}`,
  opening: 12000 + i * 500,
  received: 4500 + rand(40) * 100,
  paid: 3200 + rand(40) * 100,
  closing: 0,
})).map((r) => ({ ...r, closing: r.opening + r.received - r.paid }));

// Dashboard chart data
export const monthlyCollection = [
  { month: "May", collection: 142000, expense: 118000 },
  { month: "Jun", collection: 156000, expense: 122000 },
  { month: "Jul", collection: 168000, expense: 131000 },
  { month: "Aug", collection: 174000, expense: 135000 },
  { month: "Sep", collection: 182000, expense: 141000 },
  { month: "Oct", collection: 195000, expense: 148000 },
  { month: "Nov", collection: 208000, expense: 152000 },
];

export const distributionTrend = Array.from({ length: 14 }, (_, i) => ({
  day: `${i + 1}`,
  thalis: 88 + Math.round(Math.sin(i / 2) * 8) + rand(6),
  extra: 4 + rand(6),
}));

export const outstandingTrend = Array.from({ length: 8 }, (_, i) => ({
  week: `W${i + 1}`,
  outstanding: 45000 + Math.round(Math.cos(i / 2) * 10000) + rand(5000),
}));

export const activities = [
  { id: 1, at: "10 min ago", user: "Mustafa Bhai", action: "Received payment", target: "₹1,200 from Huzaifabhai" },
  { id: 2, at: "22 min ago", user: "Salim Khan", action: "Marked thali", target: "T-113 as Delivered" },
  { id: 3, at: "1 hr ago", user: "Anwar Sheikh", action: "Added stock", target: "50 kg Wheat Flour" },
  { id: 4, at: "2 hr ago", user: "Admin", action: "Generated invoice", target: "FMB/2025/01048" },
  { id: 5, at: "3 hr ago", user: "Mustafa Bhai", action: "Cheque deposited", target: "CHQ 100234 · ₹5,000" },
  { id: 6, at: "5 hr ago", user: "Admin", action: "Recorded donation", target: "₹11,000 - Ashara Sponsor" },
  { id: 7, at: "Yesterday", user: "Rashid Ali", action: "Extra thali entry", target: "3 guest thalis" },
  { id: 8, at: "Yesterday", user: "Admin", action: "Added family", target: "Zainabbhen Contractor" },
];
