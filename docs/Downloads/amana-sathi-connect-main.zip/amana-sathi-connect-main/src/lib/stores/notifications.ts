import { toast } from "sonner";
import { createStore } from "./store";

export type NotificationChannel = "SMS" | "WhatsApp" | "Both";
export type NotificationStatus = "Queued" | "Sent" | "Failed" | "Cancelled";
export type NotificationEvent =
  | "Payment Received"
  | "Cheque Cleared"
  | "Cheque Returned"
  | "Cheque Deposited"
  | "Invoice Generated"
  | "Contribution Reminder"
  | "Outstanding Reminder"
  | "Distribution Reminder"
  | "Expense Recorded"
  | "Donation Received";

export type AppNotification = {
  id: string;
  createdAt: string;
  event: NotificationEvent;
  channel: NotificationChannel;
  recipient: string;
  phone: string;
  message: string;
  status: NotificationStatus;
  reference?: string;
};

const seed: AppNotification[] = [
  {
    id: "N-1",
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    event: "Payment Received",
    channel: "SMS",
    recipient: "Huzaifabhai Rangwala",
    phone: "+91 9812345120",
    message:
      "Assalamu Alaikum. FMB Ratangarh has received your payment of ₹1,200 (Receipt RCP/8001). Jazakallahu Khairan.",
    status: "Sent",
    reference: "RCP/8001",
  },
  {
    id: "N-2",
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    event: "Cheque Deposited",
    channel: "WhatsApp",
    recipient: "Yusufbhai Kagalwala",
    phone: "+91 9812345121",
    message: "Your cheque no. 100234 for ₹5,000 has been deposited to SBI on today's date.",
    status: "Queued",
    reference: "CHQ 100234",
  },
];

export const notificationStore = createStore<AppNotification[]>(seed);

let counter = seed.length + 1;
const nextId = () => `N-${Date.now().toString(36).toUpperCase()}${counter++}`;

export function queueNotification(input: Omit<AppNotification, "id" | "createdAt" | "status"> & { status?: NotificationStatus }) {
  const notif: AppNotification = {
    id: nextId(),
    createdAt: new Date().toISOString(),
    status: input.status ?? "Queued",
    ...input,
  };
  notificationStore.set((prev) => [notif, ...prev]);
  toast.message(`${notif.event} · notification queued`, {
    description: `${notif.channel} → ${notif.recipient}`,
  });
  return notif;
}

export function markSent(id: string) {
  notificationStore.set((prev) => prev.map((n) => (n.id === id ? { ...n, status: "Sent" } : n)));
}
export function markFailed(id: string) {
  notificationStore.set((prev) => prev.map((n) => (n.id === id ? { ...n, status: "Failed" } : n)));
}
export function cancelNotification(id: string) {
  notificationStore.set((prev) => prev.map((n) => (n.id === id ? { ...n, status: "Cancelled" } : n)));
}
export function retryNotification(id: string) {
  notificationStore.set((prev) => prev.map((n) => (n.id === id ? { ...n, status: "Queued" } : n)));
}
export function removeNotification(id: string) {
  notificationStore.set((prev) => prev.filter((n) => n.id !== id));
}
