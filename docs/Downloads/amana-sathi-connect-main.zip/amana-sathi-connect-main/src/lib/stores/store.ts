import { useSyncExternalStore } from "react";

/**
 * Tiny module-level store with subscribe/getSnapshot semantics so we can
 * share mutable data across routes without pulling a state library.
 * All stores are API-ready: swap `set()` calls for `await fetch(...)`.
 */
export function createStore<T>(initial: T) {
  let state = initial;
  const listeners = new Set<() => void>();

  const get = () => state;
  const set = (updater: T | ((prev: T) => T)) => {
    const next =
      typeof updater === "function"
        ? (updater as (prev: T) => T)(state)
        : updater;
    if (Object.is(next, state)) return;
    state = next;
    listeners.forEach((l) => l());
  };
  const subscribe = (fn: () => void) => {
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  };

  const useStore = <S = T>(selector: (s: T) => S = (s) => s as unknown as S) =>
    useSyncExternalStore(
      subscribe,
      () => selector(state),
      () => selector(state),
    );

  return { get, set, subscribe, useStore };
}
