import { toast } from "sonner";
import { createStore } from "./store";
import { cheques as seedCheques, type Cheque as BaseCheque } from "@/lib/mock-data";

export type ChequeStatus =
  | "Issued"
  | "Deposited"
  | "Cleared"
  | "Pending"
  | "Returned"
  | "Cancelled";

export type ChequeType = "Issued" | "Received";

export type ChequeAllocation = {
  refType: "Expense" | "Payment" | "Purchase" | "Supplier";
  refId: string;
  label: string;
  amount: number;
};

export type ChequeRecord = {
  id: string;
  chequeNo: string;
  issueDate: string;
  depositDate?: string;
  clearDate?: string;
  bank: string;
  branch?: string;
  party: string;
  ledger?: string;
  amount: number;
  type: ChequeType;
  status: ChequeStatus;
  reference?: string;
  remarks?: string;
  allocations: ChequeAllocation[];
};

function fromSeed(c: BaseCheque): ChequeRecord {
  const statusMap: Record<BaseCheque["status"], ChequeStatus> = {
    Pending: "Pending",
    Cleared: "Cleared",
    Bounced: "Returned",
    Deposited: "Deposited",
  };
  return {
    id: c.id,
    chequeNo: c.chequeNo,
    issueDate: c.date,
    bank: c.bank,
    branch: "Ratangarh",
    party: c.party,
    ledger: c.type === "Received" ? "Member Collections" : "Supplier Payments",
    amount: c.amount,
    type: c.type,
    status: statusMap[c.status],
    remarks: "",
    allocations: [],
  };
}

export const chequeStore = createStore<ChequeRecord[]>(seedCheques.map(fromSeed));

let counter = seedCheques.length + 1;
const nextId = () =>
  `CHQ-${Date.now().toString(36).toUpperCase()}${counter++}`;

export function addCheque(input: Omit<ChequeRecord, "id" | "allocations"> & { allocations?: ChequeAllocation[] }) {
  const rec: ChequeRecord = {
    id: nextId(),
    allocations: input.allocations ?? [],
    ...input,
  };
  chequeStore.set((prev) => [rec, ...prev]);
  return rec;
}

export function updateCheque(id: string, patch: Partial<ChequeRecord>) {
  chequeStore.set((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
}

export function removeCheque(id: string) {
  chequeStore.set((prev) => prev.filter((c) => c.id !== id));
}

export function findChequeByNo(no: string) {
  return chequeStore.get().find((c) => c.chequeNo === no);
}

export function attachAllocation(chequeNo: string, allocation: ChequeAllocation) {
  chequeStore.set((prev) =>
    prev.map((c) =>
      c.chequeNo === chequeNo
        ? { ...c, allocations: [...c.allocations, allocation] }
        : c,
    ),
  );
}

/** Ensure a cheque exists in the register (e.g. captured from an Expense/Payment). */
export function ensureChequeFromEntry(input: {
  chequeNo: string;
  chequeDate: string;
  bank: string;
  branch?: string;
  party: string;
  type: ChequeType;
  status?: ChequeStatus;
  amount: number;
  allocation: ChequeAllocation;
  reference?: string;
  remarks?: string;
}) {
  const existing = findChequeByNo(input.chequeNo);
  if (existing) {
    attachAllocation(input.chequeNo, input.allocation);
    updateCheque(existing.id, {
      amount: existing.allocations.reduce((s, a) => s + a.amount, 0) + input.allocation.amount,
    });
    toast.message(`Added to cheque ${input.chequeNo}`, {
      description: `${input.allocation.label} · ₹${input.allocation.amount.toLocaleString("en-IN")}`,
    });
    return existing;
  }
  const rec = addCheque({
    chequeNo: input.chequeNo,
    issueDate: input.chequeDate,
    bank: input.bank,
    branch: input.branch,
    party: input.party,
    amount: input.amount,
    type: input.type,
    status: input.status ?? "Pending",
    reference: input.reference,
    remarks: input.remarks,
    allocations: [input.allocation],
  });
  return rec;
}
