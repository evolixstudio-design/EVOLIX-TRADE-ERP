import { createStore } from "./store";
import { families } from "@/lib/mock-data";

export type AttendanceStatus = "Taken" | "Not Taken";

export type AttendanceRecord = {
  date: string; // YYYY-MM-DD
  familyId: string;
  status: AttendanceStatus;
  remarks?: string;
  markedAt: string;
};

const today = new Date().toISOString().slice(0, 10);

// Seed: last 21 days with realistic status per family
function buildSeed(): AttendanceRecord[] {
  const out: AttendanceRecord[] = [];
  const now = new Date();
  for (let d = 0; d < 21; d++) {
    const dt = new Date(now);
    dt.setDate(dt.getDate() - d);
    const iso = dt.toISOString().slice(0, 10);
    families.forEach((f, i) => {
      // Skip today for the last ~15 families so operator has something to mark
      if (d === 0 && i > families.length - 16) return;
      const notTaken = (i + d) % 11 === 0;
      out.push({
        date: iso,
        familyId: f.id,
        status: notTaken ? "Not Taken" : "Taken",
        remarks: notTaken && (i + d) % 3 === 0 ? "Family out of town" : "",
        markedAt: `${dt.toISOString().slice(0, 10)}T12:00:00`,
      });
    });
  }
  return out;
}

export const attendanceStore = createStore<AttendanceRecord[]>(buildSeed());

export const todayIso = () => today;

export function setAttendance(
  date: string,
  familyId: string,
  status: AttendanceStatus,
  remarks = "",
) {
  attendanceStore.set((prev) => {
    const idx = prev.findIndex((r) => r.date === date && r.familyId === familyId);
    const record: AttendanceRecord = {
      date,
      familyId,
      status,
      remarks,
      markedAt: new Date().toISOString(),
    };
    if (idx === -1) return [...prev, record];
    const clone = [...prev];
    clone[idx] = record;
    return clone;
  });
}

export function clearAttendance(date: string, familyId: string) {
  attendanceStore.set((prev) =>
    prev.filter((r) => !(r.date === date && r.familyId === familyId)),
  );
}

export function attendanceForDate(records: AttendanceRecord[], date: string) {
  return records.filter((r) => r.date === date);
}

export function summarize(records: AttendanceRecord[], date: string) {
  const day = attendanceForDate(records, date);
  const taken = day.filter((r) => r.status === "Taken").length;
  const notTaken = day.filter((r) => r.status === "Not Taken").length;
  const total = families.length;
  const unmarked = total - day.length;
  return { taken, notTaken, unmarked, total };
}

export function monthSummary(records: AttendanceRecord[], year: number, month: number) {
  const prefix = `${year}-${String(month + 1).padStart(2, "0")}`;
  const days = records.filter((r) => r.date.startsWith(prefix));
  const taken = days.filter((r) => r.status === "Taken").length;
  const notTaken = days.filter((r) => r.status === "Not Taken").length;
  const distinctDates = new Set(days.map((r) => r.date));
  return { taken, notTaken, days: distinctDates.size };
}
