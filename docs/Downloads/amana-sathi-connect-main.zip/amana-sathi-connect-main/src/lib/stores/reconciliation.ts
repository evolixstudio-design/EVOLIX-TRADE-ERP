import { createStore } from "./store";

export type StatementLine = {
  id: string;
  date: string;
  description: string;
  chequeNo?: string;
  reference?: string;
  debit: number; // money out (bank pays)
  credit: number; // money in (bank receives)
  matchedChequeId?: string;
};

// Seed a mock uploaded statement for demo purposes.
const seed: StatementLine[] = [
  { id: "ST-1", date: "2025-11-04", description: "CHQ 100000 CLR", chequeNo: "100000", debit: 0, credit: 4500 },
  { id: "ST-2", date: "2025-11-06", description: "CHQ 100003 CLR", chequeNo: "100003", debit: 3200, credit: 0 },
  { id: "ST-3", date: "2025-11-09", description: "NEFT INWARD 8291", reference: "NEFT8291", debit: 0, credit: 12500 },
  { id: "ST-4", date: "2025-11-12", description: "CHQ 100006 CLR", chequeNo: "100006", debit: 0, credit: 6800 },
  { id: "ST-5", date: "2025-11-14", description: "CHQ 100009 RTN", chequeNo: "100009", debit: 0, credit: -2500 },
  { id: "ST-6", date: "2025-11-16", description: "UPI CR RATANGARH", reference: "UPI7712", debit: 0, credit: 3400 },
  { id: "ST-7", date: "2025-11-18", description: "CHQ 100012 CLR", chequeNo: "100012", debit: 5400, credit: 0 },
  { id: "ST-8", date: "2025-11-20", description: "BANK CHARGES", debit: 236, credit: 0 },
];

export const statementStore = createStore<StatementLine[]>(seed);

export function addStatementLine(line: Omit<StatementLine, "id">) {
  statementStore.set((prev) => [
    { id: `ST-${Date.now().toString(36).toUpperCase()}`, ...line },
    ...prev,
  ]);
}

export function setMatch(statementId: string, chequeId: string | undefined) {
  statementStore.set((prev) =>
    prev.map((s) => (s.id === statementId ? { ...s, matchedChequeId: chequeId } : s)),
  );
}
