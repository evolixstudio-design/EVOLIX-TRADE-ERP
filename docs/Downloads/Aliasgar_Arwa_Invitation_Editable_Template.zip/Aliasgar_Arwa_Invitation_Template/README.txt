EDITABLE INVITATION VIDEO TEMPLATE

Current values:
  Groom: Aliasgar
  Bride: Arwa
  Date: Sunday, 30 August 2026

The original 39.79-second vertical video, animations, florals, illustrations,
transitions and soundtrack are retained. Only the two name lines and date card
are rebuilt as editable overlays.

TO CHANGE THE NAMES OR DATE
1. Open render_template.sh.
2. Change only the values inside TEMPLATE_VALUES near the top.
3. Run: bash render_template.sh
4. The finished MP4 is created in this folder.

Requirement: FFmpeg with drawtext and delogo support.

Note: The source was a flattened MP4, so its original individual Canva layers
cannot be recovered. This package is the reusable editable reconstruction.
