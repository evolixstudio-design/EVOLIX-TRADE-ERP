#!/usr/bin/env bash
set -euo pipefail

# EDIT ONLY THESE FOUR VALUES
GROOM_NAME="Aliasgar"
BRIDE_NAME="Arwa"
WEEKDAY="ON SUNDAY"
EVENT_DATE="30TH AUGUST 2026"

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$ROOT_DIR/source_invitation.mp4"
OUTPUT="$ROOT_DIR/Aliasgar_Arwa_30_August.mp4"
SCRIPT_FONT="/usr/share/fonts/opentype/urw-base35/Z003-MediumItalic.otf"
SERIF_FONT="/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"

ffmpeg -y -loglevel error -i "$SOURCE" -vf \
"delogo=x=100:y=390:w=285:h=65:show=0:enable='between(t,16.25,21.55)',\
 delogo=x=65:y=520:w=350:h=72:show=0:enable='between(t,16.25,21.55)',\
 drawtext=fontfile='$SCRIPT_FONT':text='$GROOM_NAME':fontsize=55:fontcolor=0x4C523E:x=(w-text_w)/2:y=392:enable='between(t,16.45,21.35)',\
 drawtext=fontfile='$SCRIPT_FONT':text='$BRIDE_NAME':fontsize=55:fontcolor=0x4C523E:x=(w-text_w)/2:y=520:enable='between(t,16.45,21.35)',\
 delogo=x=130:y=445:w=260:h=75:show=0:enable='between(t,21.35,25.70)',\
 drawtext=fontfile='$SERIF_FONT':text='$WEEKDAY':fontsize=18:fontcolor=0x4C523E:x=(w-text_w)/2:y=447:enable='between(t,21.55,25.50)',\
 drawtext=fontfile='$SERIF_FONT':text='$EVENT_DATE':fontsize=21:fontcolor=0x4C523E:x=(w-text_w)/2:y=479:enable='between(t,21.55,25.50)'" \
-c:v libx264 -preset medium -crf 18 -c:a copy -movflags +faststart "$OUTPUT"

printf '%s\n' "$OUTPUT"
